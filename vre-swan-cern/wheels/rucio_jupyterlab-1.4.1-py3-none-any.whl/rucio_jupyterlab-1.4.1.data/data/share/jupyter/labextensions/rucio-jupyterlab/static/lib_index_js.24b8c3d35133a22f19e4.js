"use strict";
(self["webpackChunkrucio_jupyterlab"] = self["webpackChunkrucio_jupyterlab"] || []).push([["lib_index_js"],{

/***/ "./lib/components/@Explore/AddToNotebookPopover.js":
/*!*********************************************************!*\
  !*** ./lib/components/@Explore/AddToNotebookPopover.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AddToNotebookPopover: () => (/* binding */ AddToNotebookPopover)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_popover__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-popover */ "webpack/sharing/consume/default/react-popover/react-popover");
/* harmony import */ var react_popover__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_popover__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! pullstate */ "webpack/sharing/consume/default/pullstate/pullstate");
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(pullstate__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _stores_ExtensionStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../stores/ExtensionStore */ "./lib/stores/ExtensionStore.js");
/* harmony import */ var _TextField__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../TextField */ "./lib/components/TextField.js");
/* harmony import */ var _utils_Helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../utils/Helpers */ "./lib/utils/Helpers.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */







const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_2__.createUseStyles)({
    main: {
        background: 'var(--jp-layout-color1)',
        color: 'var(--jp-ui-font-color1)'
    },
    textField: {
        width: '200px',
        background: 'var(--jp-layout-color1)',
        color: 'var(--jp-ui-font-color1)'
    },
    instructions: {
        padding: '8px',
        fontSize: '8pt',
        background: 'var(--jp-layout-color2)',
        color: 'var(--jp-ui-font-color2)'
    },
    proceedButton: {
        alignItems: 'center',
        padding: '4px',
        lineHeight: 0,
        cursor: 'pointer'
    },
    proceedIcon: {
        color: 'var(--jp-rucio-primary-blue-color)',
        opacity: 0.5,
        fontSize: '16px',
        lineHeight: '24px',
        '&:hover': {
            color: 'var(--jp-rucio-primary-blue-color)',
            opacity: 1
        }
    },
    error: {
        color: 'var(--jp-error-color2)'
    }
});
const AddToNotebookPopover = ({ children, did, type }) => {
    const classes = useStyles();
    const textFieldRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const [varName, setVarName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const activeNotebookPanel = (0,pullstate__WEBPACK_IMPORTED_MODULE_3__.useStoreState)(_stores_ExtensionStore__WEBPACK_IMPORTED_MODULE_4__.ExtensionStore, s => s.activeNotebookPanel);
    const activeNotebookAttachments = (0,pullstate__WEBPACK_IMPORTED_MODULE_3__.useStoreState)(_stores_ExtensionStore__WEBPACK_IMPORTED_MODULE_4__.ExtensionStore, s => s.activeNotebookAttachment);
    const existingAttachmentVariableNames = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => activeNotebookAttachments
        ? activeNotebookAttachments.map(a => a.variableName)
        : [], [activeNotebookAttachments]);
    const didAttached = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => activeNotebookAttachments
        ? !!activeNotebookAttachments.find(a => a.did === did)
        : false, [activeNotebookAttachments]);
    const setActiveNotebookAttachments = (attachments) => {
        _stores_ExtensionStore__WEBPACK_IMPORTED_MODULE_4__.ExtensionStore.update(s => {
            s.activeNotebookAttachment = attachments;
        });
    };
    const escFunction = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((event) => {
        if (event.keyCode === 27) {
            setOpen(false);
        }
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        document.addEventListener('keydown', escFunction, false);
        return () => {
            document.removeEventListener('keydown', escFunction, false);
        };
    }, []);
    const addAttachment = () => {
        if (!(0,_utils_Helpers__WEBPACK_IMPORTED_MODULE_5__.checkVariableNameValid)(varName) || checkVariableNameExists(varName)) {
            return;
        }
        setOpen(false);
        const attachment = {
            did,
            type,
            variableName: varName
        };
        const notebookAttachments = activeNotebookAttachments
            ? [...activeNotebookAttachments, attachment]
            : [attachment];
        setActiveNotebookAttachments(notebookAttachments);
    };
    const handleKeyPress = (e) => {
        if (e.key === 'Enter') {
            addAttachment();
        }
    };
    const checkVariableNameExists = (variableName) => {
        return existingAttachmentVariableNames.includes(variableName);
    };
    const handleTextChange = (variableName) => {
        setVarName(variableName);
        if (!!variableName && !(0,_utils_Helpers__WEBPACK_IMPORTED_MODULE_5__.checkVariableNameValid)(variableName)) {
            setError('Invalid variable name');
        }
        else if (checkVariableNameExists(variableName)) {
            setError('Variable name exists');
        }
        else {
            setError(undefined);
        }
    };
    const proceedButton = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.proceedButton, onClick: addAttachment },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.proceedIcon} material-icons` }, "arrow_forward")));
    const popoverBody = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.main },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_TextField__WEBPACK_IMPORTED_MODULE_6__.TextField, { ref: textFieldRef, className: classes.textField, outlineColor: "var(--jp-layout-color1)", placeholder: "Enter a variable name", onKeyPress: handleKeyPress, after: proceedButton, value: varName, onChange: e => handleTextChange(e.target.value) }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.instructions },
            !error && react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Press Enter to proceed, Esc to cancel"),
            !!error && react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: classes.error }, error))));
    const openPopover = () => {
        setOpen(true);
        setVarName('');
        setError(undefined);
        setTimeout(() => {
            var _a;
            (_a = textFieldRef.current) === null || _a === void 0 ? void 0 : _a.focus();
        }, 10);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, !!activeNotebookPanel && !didAttached && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_popover__WEBPACK_IMPORTED_MODULE_1___default()), { enterExitTransitionDurationMs: 0, isOpen: open, preferPlace: "below", body: popoverBody, onOuterAction: () => setOpen(false) },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { onClick: openPopover }, children)))));
};


/***/ }),

/***/ "./lib/components/@Explore/CollectionDIDItemDetails.js":
/*!*************************************************************!*\
  !*** ./lib/components/@Explore/CollectionDIDItemDetails.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CollectionDIDItemDetails: () => (/* binding */ CollectionDIDItemDetails)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! pullstate */ "webpack/sharing/consume/default/pullstate/pullstate");
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(pullstate__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _const__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../const */ "./lib/const.js");
/* harmony import */ var _stores_UIStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../stores/UIStore */ "./lib/stores/UIStore.js");
/* harmony import */ var _Spinning__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../Spinning */ "./lib/components/Spinning.js");
/* harmony import */ var _utils_Actions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../utils/Actions */ "./lib/utils/Actions.js");
/* harmony import */ var _AddToNotebookPopover__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./AddToNotebookPopover */ "./lib/components/@Explore/AddToNotebookPopover.js");
/* harmony import */ var _utils_Helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../utils/Helpers */ "./lib/utils/Helpers.js");
/* harmony import */ var _utils_DIDPollingManager__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../utils/DIDPollingManager */ "./lib/utils/DIDPollingManager.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 * - Giovanni Guerrieri, <giovanni.guerrieri@cern.ch>, 2025
 */












const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    container: {
        padding: '4px 16px 4px 16px',
        backgroundColor: 'var(--jp-layout-color2)',
        boxSizing: 'border-box',
        height: '32px',
        alignItems: 'center'
    },
    icon: {
        fontSize: '10pt',
        verticalAlign: 'middle'
    },
    loading: {
        color: 'var(--jp-ui-font-color2)'
    },
    statusText: {
        fontSize: '9pt',
        verticalAlign: 'middle',
        paddingLeft: '4px',
        flex: 1,
        textOverflow: 'ellipsis',
        overflow: 'hidden',
        whiteSpace: 'nowrap'
    },
    clickableStatusText: {
        extend: 'statusText',
        '& a:hover': {
            textDecoration: 'underline',
            cursor: 'pointer'
        }
    },
    statusContainer: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        flex: 1
    },
    statusAvailable: {
        extend: 'statusContainer',
        color: 'var(--jp-success-color0)'
    },
    statusPartiallyAvailable: {
        extend: 'statusContainer',
        color: 'var(--jp-rucio-yellow-color)'
    },
    statusEmpty: {
        extend: 'statusContainer',
        color: 'var(--jp-rucio-yellow-color)'
    },
    statusNotAvailable: {
        extend: 'statusContainer',
        color: 'var(--jp-error-color1)'
    },
    statusReplicating: {
        extend: 'statusContainer',
        color: 'var(--jp-rucio-yellow-color)'
    },
    statusFetching: {
        extend: 'statusContainer',
        color: 'var(--jp-ui-font-color1)'
    },
    action: {
        fontSize: '9pt',
        color: 'var(--jp-rucio-primary-blue-color)',
        cursor: 'pointer'
    }
});
const _CollectionDIDItemDetails = ({ did, ...props }) => {
    const classes = useStyles();
    const { actions } = props;
    const { didPollingManager } = props;
    const collectionAttachedFiles = (0,pullstate__WEBPACK_IMPORTED_MODULE_2__.useStoreState)(_stores_UIStore__WEBPACK_IMPORTED_MODULE_5__.UIStore, s => s.collectionDetails[did]);
    const activeInstance = (0,pullstate__WEBPACK_IMPORTED_MODULE_2__.useStoreState)(_stores_UIStore__WEBPACK_IMPORTED_MODULE_5__.UIStore, s => s.activeInstance);
    const [pollingRequesterRef] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => new _utils_DIDPollingManager__WEBPACK_IMPORTED_MODULE_6__.PollingRequesterRef());
    const enablePolling = () => {
        // Optimistically set FETCHING status immediately to avoid showing "Not Available"
        const existingData = _stores_UIStore__WEBPACK_IMPORTED_MODULE_5__.UIStore.getRawState().collectionDetails[did];
        if (!existingData) {
            _stores_UIStore__WEBPACK_IMPORTED_MODULE_5__.UIStore.update(s => {
                s.collectionDetails[did] = [
                    {
                        status: 'FETCHING',
                        did: did,
                        path: undefined,
                        size: 0,
                        message: 'Fetching replica information...'
                    }
                ];
            });
        }
        didPollingManager.requestPolling(did, 'collection', pollingRequesterRef);
    };
    const disablePolling = () => {
        didPollingManager.disablePolling(did, pollingRequesterRef);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        enablePolling();
        return () => {
            disablePolling();
        };
    }, []);
    const makeAvailable = () => {
        if (!activeInstance) {
            return;
        }
        actions === null || actions === void 0 ? void 0 : actions.makeCollectionAvailable(activeInstance.name, did).then(() => enablePolling()).catch(e => console.log(e)); // TODO handle error
    };
    const collectionState = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
        return collectionAttachedFiles
            ? (0,_utils_Helpers__WEBPACK_IMPORTED_MODULE_7__.computeCollectionState)(collectionAttachedFiles)
            : undefined;
    }, [collectionAttachedFiles]);
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.makeSettings();
    const redirectorUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_3__.URLExt.join(settings.baseUrl, _const__WEBPACK_IMPORTED_MODULE_8__.EXTENSION_ID, 'open-replication-rule');
    const showReplicationRuleUrl = (activeInstance === null || activeInstance === void 0 ? void 0 : activeInstance.webuiUrl) && activeInstance.mode === 'replica'
        ? `${redirectorUrl}?namespace=${activeInstance === null || activeInstance === void 0 ? void 0 : activeInstance.name}&did=${did}`
        : undefined;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.container },
        (!collectionAttachedFiles || collectionState === 'FETCHING') && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.loading },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Spinning__WEBPACK_IMPORTED_MODULE_9__.Spinning, { className: `${classes.icon} material-icons` }, "hourglass_top"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: classes.statusText }, "Fetching replica information..."))),
        collectionState === 'AVAILABLE' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(FileAvailable, { did: did, showReplicationRuleUrl: showReplicationRuleUrl })),
        collectionState === 'PARTIALLY_AVAILABLE' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(FilePartiallyAvailable, { onMakeAvailableClicked: makeAvailable, showReplicationRuleUrl: showReplicationRuleUrl })),
        collectionState === 'NOT_AVAILABLE' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(FileNotAvailable, { onMakeAvailableClicked: makeAvailable })),
        collectionState === 'REPLICATING' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(FileReplicating, { did: did, showReplicationRuleUrl: showReplicationRuleUrl })),
        collectionState === 'STUCK' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(FileStuck, { onMakeAvailableClicked: (activeInstance === null || activeInstance === void 0 ? void 0 : activeInstance.mode) === 'download' ? makeAvailable : undefined, showReplicationRuleUrl: showReplicationRuleUrl })),
        collectionState === 'EMPTY' && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(FileEmpty, null)));
};
const FileAvailable = ({ did, showReplicationRuleUrl }) => {
    const classes = useStyles();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusAvailable },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.icon} material-icons` }, "check_circle"),
        showReplicationRuleUrl && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.clickableStatusText },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { href: showReplicationRuleUrl, target: "_blank", rel: "noreferrer", title: "Show replication rule" }, "All files available"))),
        !showReplicationRuleUrl && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusText }, "All files available")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.action },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_AddToNotebookPopover__WEBPACK_IMPORTED_MODULE_10__.AddToNotebookPopover, { did: did, type: "collection" }, "Add to Notebook"))));
};
const FileNotAvailable = ({ onMakeAvailableClicked }) => {
    const classes = useStyles();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusNotAvailable },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.icon} material-icons` }, "lens"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusText }, "Not available"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.action, onClick: onMakeAvailableClicked }, "Make Available")));
};
const FilePartiallyAvailable = ({ onMakeAvailableClicked, showReplicationRuleUrl }) => {
    const classes = useStyles();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusPartiallyAvailable },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.icon} material-icons` }, "lens"),
        showReplicationRuleUrl && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.clickableStatusText },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { href: showReplicationRuleUrl, target: "_blank", rel: "noreferrer", title: "Show replication rule" }, "Partially available"))),
        !showReplicationRuleUrl && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusText }, "Partially available")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.action, onClick: onMakeAvailableClicked }, "Make Available")));
};
const FileReplicating = ({ did, showReplicationRuleUrl }) => {
    const classes = useStyles();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusReplicating },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Spinning__WEBPACK_IMPORTED_MODULE_9__.Spinning, { className: `${classes.icon} material-icons` }, "hourglass_top"),
        showReplicationRuleUrl && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.clickableStatusText },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { href: showReplicationRuleUrl, target: "_blank", rel: "noreferrer", title: "Show replication rule" }, "Replicating files..."))),
        !showReplicationRuleUrl && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusText }, "Replicating files...")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.action },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_AddToNotebookPopover__WEBPACK_IMPORTED_MODULE_10__.AddToNotebookPopover, { did: did, type: "collection" }, "Add to Notebook"))));
};
const FileStuck = ({ onMakeAvailableClicked, showReplicationRuleUrl }) => {
    const classes = useStyles();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusNotAvailable },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.icon} material-icons` }, "error"),
        showReplicationRuleUrl && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.clickableStatusText },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { href: showReplicationRuleUrl, target: "_blank", rel: "noreferrer", title: "Show replication rule" }, "Something went wrong"))),
        !showReplicationRuleUrl && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusText }, "Something went wrong")),
        onMakeAvailableClicked && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.action, onClick: onMakeAvailableClicked }, "Make Available"))));
};
const FileEmpty = () => {
    const classes = useStyles();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusEmpty },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.icon} material-icons` }, "warning"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusText }, "Collection is empty")));
};
const CollectionDIDItemDetails = (0,_utils_DIDPollingManager__WEBPACK_IMPORTED_MODULE_6__.withPollingManager)((0,_utils_Actions__WEBPACK_IMPORTED_MODULE_11__.withRequestAPI)(_CollectionDIDItemDetails));


/***/ }),

/***/ "./lib/components/@Explore/DIDListItem.js":
/*!************************************************!*\
  !*** ./lib/components/@Explore/DIDListItem.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DIDListItem: () => (/* binding */ DIDListItem)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _FileDIDItemDetails__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./FileDIDItemDetails */ "./lib/components/@Explore/FileDIDItemDetails.js");
/* harmony import */ var _CollectionDIDItemDetails__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./CollectionDIDItemDetails */ "./lib/components/@Explore/CollectionDIDItemDetails.js");
/* harmony import */ var _utils_Helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../utils/Helpers */ "./lib/utils/Helpers.js");
/* harmony import */ var _ListAttachedFilesPopover__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ListAttachedFilesPopover */ "./lib/components/@Explore/ListAttachedFilesPopover.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */






const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    listItemContainer: {
        borderBottom: '1px solid var(--jp-border-color2)',
        overflow: 'hidden',
        boxSizing: 'border-box'
    },
    listItem: {
        display: 'flex',
        flexDirection: 'row',
        fontSize: '9pt',
        alignItems: 'center',
        padding: '8px 16px 8px 16px',
        cursor: 'pointer'
    },
    listItemCollapsed: {
        extend: 'listItem',
        '&:hover': {
            backgroundColor: 'var(--jp-layout-color2)'
        }
    },
    listItemExpanded: {
        extend: 'listItem',
        backgroundColor: 'var(--jp-layout-color2)'
    },
    textContainer: {
        flex: 1,
        textOverflow: 'ellipsis',
        overflow: 'hidden',
        whiteSpace: 'nowrap'
    },
    iconContainer: {
        lineHeight: 0,
        marginRight: '8px'
    },
    icon: {
        fontSize: '16px',
        verticalAlign: 'middle'
    },
    fileIcon: {
        extend: 'icon',
        color: '#66B100'
    },
    containerIcon: {
        extend: 'icon',
        color: '#5DC0FD'
    },
    datasetIcon: {
        extend: 'icon',
        color: '#FFB100'
    },
    sizeContainer: {
        color: 'var(--jp-ui-font-color2)'
    },
    listFilesIcon: {
        extend: 'icon',
        color: '#2196F3',
        cursor: 'pointer'
    }
});
const DIDListItem = ({ did, size, type, onClick, expand, style }) => {
    const classes = useStyles();
    const handleViewFilesClick = (e) => {
        e.stopPropagation();
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.listItemContainer, style: style },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: expand ? classes.listItemExpanded : classes.listItemCollapsed, onClick: onClick },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.iconContainer },
                type === 'file' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.fileIcon} material-icons` }, "attachment")),
                type === 'container' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.containerIcon} material-icons` }, "folder")),
                type === 'dataset' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.datasetIcon} material-icons` }, "folder_open"))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.textContainer }, did),
            type === 'file' && !!size && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.sizeContainer }, (0,_utils_Helpers__WEBPACK_IMPORTED_MODULE_2__.toHumanReadableSize)(size))),
            (type === 'container' || type === 'dataset') && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { onClick: handleViewFilesClick },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ListAttachedFilesPopover__WEBPACK_IMPORTED_MODULE_3__.ListAttachedFilesPopover, { did: did },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.listFilesIcon} material-icons` }, "visibility"))))),
        !!expand && type === 'file' && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_FileDIDItemDetails__WEBPACK_IMPORTED_MODULE_4__.FileDIDItemDetails, { did: did }),
        !!expand && (type === 'container' || type === 'dataset') && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_CollectionDIDItemDetails__WEBPACK_IMPORTED_MODULE_5__.CollectionDIDItemDetails, { did: did }))));
};


/***/ }),

/***/ "./lib/components/@Explore/ExploreTab.js":
/*!***********************************************!*\
  !*** ./lib/components/@Explore/ExploreTab.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ExploreTab: () => (/* binding */ ExploreTab)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_window__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-window */ "webpack/sharing/consume/default/react-window/react-window");
/* harmony import */ var react_window__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_window__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-virtualized-auto-sizer */ "webpack/sharing/consume/default/react-virtualized-auto-sizer/react-virtualized-auto-sizer");
/* harmony import */ var react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! pullstate */ "webpack/sharing/consume/default/pullstate/pullstate");
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(pullstate__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _stores_UIStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../stores/UIStore */ "./lib/stores/UIStore.js");
/* harmony import */ var _components_TextField__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../components/TextField */ "./lib/components/TextField.js");
/* harmony import */ var _components_HorizontalHeading__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../components/HorizontalHeading */ "./lib/components/HorizontalHeading.js");
/* harmony import */ var _components_Explore_DIDListItem__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../components/@Explore/DIDListItem */ "./lib/components/@Explore/DIDListItem.js");
/* harmony import */ var _components_Spinning__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../components/Spinning */ "./lib/components/Spinning.js");
/* harmony import */ var _utils_Actions__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../utils/Actions */ "./lib/utils/Actions.js");
/* harmony import */ var _components_Explore_InlineDropdown__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../components/../@Explore/InlineDropdown */ "./lib/components/@Explore/InlineDropdown.js");
/* harmony import */ var _components_Explore_ListScopesPopover__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../components/../@Explore/ListScopesPopover */ "./lib/components/@Explore/ListScopesPopover.js");
/* harmony import */ var _components_Explore_MetadataFilterContainer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../components/../@Explore/MetadataFilterContainer */ "./lib/components/@Explore/MetadataFilterContainer.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020-2021
 */














const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    mainContainer: {
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden'
    },
    searchContainer: {
        padding: '8px'
    },
    filterContainer: {
        padding: '0 16px 0 16px',
        fontSize: '9pt'
    },
    resultsContainer: {
        flex: 1
    },
    searchButton: {
        alignItems: 'center',
        padding: '8px 8px 8px 4px',
        lineHeight: 0,
        cursor: 'pointer'
    },
    searchIcon: {
        fontSize: '18px',
        color: 'var(--jp-rucio-primary-blue-color)',
        opacity: 0.5,
        '&:hover': {
            opacity: 1
        }
    },
    listScopesButton: {
        alignItems: 'center',
        padding: '8px 4px 8px 4px',
        lineHeight: 0,
        cursor: 'pointer'
    },
    listScopesIcon: {
        fontSize: '18px',
        color: 'var(--jp-layout-color4)',
        opacity: 0.5,
        '&:hover': {
            opacity: 1
        }
    },
    dropdown: {
        color: 'var(--jp-rucio-primary-blue-color)',
        cursor: 'pointer',
        marginLeft: '4px'
    },
    loading: {
        padding: '16px'
    },
    icon: {
        fontSize: '10pt',
        verticalAlign: 'middle'
    },
    iconText: {
        verticalAlign: 'middle',
        paddingLeft: '4px'
    },
    errorText: {
        padding: '16px',
        color: 'red',
        flex: 1
    }
});
const searchByOptions = [
    { title: 'Everything', value: 'all' },
    { title: 'Datasets and Containers', value: 'collection' },
    { title: 'Datasets', value: 'dataset' },
    { title: 'Containers', value: 'container' },
    { title: 'Files', value: 'file' }
];
const _Explore = props => {
    const classes = useStyles();
    const { actions } = props;
    const [searchQuery, setSearchQuery] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [searchType, setSearchType] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('all');
    const [searchResult, setSearchResult] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const [didExpanded, setDidExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [searchTrigger, setSearchTrigger] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const activeInstance = (0,pullstate__WEBPACK_IMPORTED_MODULE_4__.useStoreState)(_stores_UIStore__WEBPACK_IMPORTED_MODULE_5__.UIStore, s => s.activeInstance);
    const [metadataFilters, setMetadataFilters] = react__WEBPACK_IMPORTED_MODULE_0___default().useState([]);
    const doSearch = () => {
        setSearchTrigger(prev => prev + 1); // Increment the counter to trigger the search
    };
    const buildMetadataFilterString = () => {
        return metadataFilters
            .map((filter, index) => {
            const logic = index === 0 ? '' : filter.logic === 'And' ? ',' : ';';
            return `${logic}${filter.key}${filter.operator}${filter.value}`;
        })
            .join('');
    };
    const itemsSortFunction = (a, b) => {
        if (a.type === b.type) {
            return a.did.toLowerCase() < b.did.toLowerCase() ? -1 : 1;
        }
        if (a.type === 'container' && b.type === 'dataset') {
            return -1;
        }
        if ((a.type === 'container' || a.type === 'dataset') && b.type === 'file') {
            return -1;
        }
        return 1;
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!searchQuery || !activeInstance) {
            return;
        }
        setLoading(true);
        setSearchResult(undefined);
        setDidExpanded({});
        setError(undefined);
        const filterString = buildMetadataFilterString();
        actions
            .searchDID(activeInstance.name, searchQuery, searchType, filterString)
            .then(items => items.sort(itemsSortFunction))
            .then(result => setSearchResult(result))
            .catch(e => {
            setSearchResult([]);
            // The error 'e' is the rich ResponseError object from requestAPI
            if (e.response && e.response.status === 401) {
                setError('Authentication error. Perhaps you set an invalid credential?');
                return;
            }
            // The backend error message is directly available on e.error
            if (e.error) {
                setError(e.error);
            }
            else {
                // Fallback to the general error message if e.error is not present
                setError(e.message || 'An unknown error occurred.');
            }
        })
            .finally(() => setLoading(false));
    }, [searchTrigger, searchType]);
    const searchBoxRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const onScopeClicked = (scope) => {
        var _a;
        setSearchQuery(scope + ':');
        (_a = searchBoxRef === null || searchBoxRef === void 0 ? void 0 : searchBoxRef.current) === null || _a === void 0 ? void 0 : _a.focus();
    };
    const listScopesButton = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Explore_ListScopesPopover__WEBPACK_IMPORTED_MODULE_6__.ListScopesPopover, { onScopeClicked: onScopeClicked, key: "list-scopes-button" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.listScopesButton },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.listScopesIcon} material-icons` }, "topic"))));
    const searchButton = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.searchButton, onClick: doSearch, key: "search-button" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.searchIcon} material-icons` }, "search")));
    const handleKeyPress = (e) => {
        if (e.key === 'Enter') {
            doSearch();
        }
    };
    const listRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const toggleExpand = (index) => {
        var _a;
        (_a = listRef.current) === null || _a === void 0 ? void 0 : _a.resetAfterIndex(index);
        didExpanded[index] = !didExpanded[index];
        setDidExpanded(didExpanded);
    };
    const getItemHeight = (i) => (didExpanded[i] === true ? 64 : 32);
    const Row = ({ index, style }) => {
        if (!searchResult) {
            return react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null);
        }
        const item = searchResult[index];
        const expanded = !!didExpanded[index];
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Explore_DIDListItem__WEBPACK_IMPORTED_MODULE_7__.DIDListItem, { style: style, type: item.type, did: item.did, size: item.size, key: item.did, expand: expanded, onClick: () => toggleExpand(index) }));
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.mainContainer },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.searchContainer },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_TextField__WEBPACK_IMPORTED_MODULE_8__.TextField, { placeholder: "Enter a Data Identifier (DID)", after: [listScopesButton, searchButton], value: searchQuery, onChange: e => setSearchQuery(e.target.value), onKeyPress: handleKeyPress, autoComplete: "off", ref: searchBoxRef })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.filterContainer },
            "Search",
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Explore_InlineDropdown__WEBPACK_IMPORTED_MODULE_9__.InlineDropdown, { className: classes.dropdown, options: searchByOptions, value: searchType, onItemSelected: setSearchType, optionWidth: "180px" })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Explore_MetadataFilterContainer__WEBPACK_IMPORTED_MODULE_10__.MetadataFilterContainer, { onKeyPress: handleKeyPress, metadataFilters: metadataFilters, setMetadataFilters: setMetadataFilters }),
        loading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.loading },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Spinning__WEBPACK_IMPORTED_MODULE_11__.Spinning, { className: `${classes.icon} material-icons` }, "hourglass_top"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: classes.iconText }, "Loading..."))),
        !!searchResult && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
            !error && !!searchResult && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_HorizontalHeading__WEBPACK_IMPORTED_MODULE_12__.HorizontalHeading, { title: "Search Results" })),
            !!error && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_HorizontalHeading__WEBPACK_IMPORTED_MODULE_12__.HorizontalHeading, { title: "Error(s) found" }),
            !!error && react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.errorText }, error),
            !error && searchResult && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                searchResult.length === 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.loading }, "No results found")),
                searchResult.length > 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.resultsContainer },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_3___default()), { disableWidth: true }, ({ height }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_window__WEBPACK_IMPORTED_MODULE_2__.VariableSizeList, { ref: listRef, height: height, itemCount: searchResult.length, itemSize: getItemHeight, width: "100%" }, Row)))))))))));
};
const ExploreTab = (0,_utils_Actions__WEBPACK_IMPORTED_MODULE_13__.withRequestAPI)(_Explore);


/***/ }),

/***/ "./lib/components/@Explore/FileDIDItemDetails.js":
/*!*******************************************************!*\
  !*** ./lib/components/@Explore/FileDIDItemDetails.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FileDIDItemDetails: () => (/* binding */ FileDIDItemDetails)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! pullstate */ "webpack/sharing/consume/default/pullstate/pullstate");
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(pullstate__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _const__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../const */ "./lib/const.js");
/* harmony import */ var _stores_UIStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../stores/UIStore */ "./lib/stores/UIStore.js");
/* harmony import */ var _Spinning__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../Spinning */ "./lib/components/Spinning.js");
/* harmony import */ var _utils_Actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../utils/Actions */ "./lib/utils/Actions.js");
/* harmony import */ var _AddToNotebookPopover__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./AddToNotebookPopover */ "./lib/components/@Explore/AddToNotebookPopover.js");
/* harmony import */ var _utils_DIDPollingManager__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../utils/DIDPollingManager */ "./lib/utils/DIDPollingManager.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */











const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    container: {
        padding: '4px 16px 4px 16px',
        backgroundColor: 'var(--jp-layout-color2)',
        boxSizing: 'border-box',
        height: '32px',
        alignItems: 'center'
    },
    icon: {
        fontSize: '10pt',
        verticalAlign: 'middle'
    },
    loading: {
        color: 'var(--jp-ui-font-color2)'
    },
    statusText: {
        fontSize: '9pt',
        verticalAlign: 'middle',
        paddingLeft: '4px',
        flex: 1,
        textOverflow: 'ellipsis',
        overflow: 'hidden',
        whiteSpace: 'nowrap'
    },
    clickableStatusText: {
        extend: 'statusText',
        '& a:hover': {
            textDecoration: 'underline',
            cursor: 'pointer'
        }
    },
    statusContainer: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        flex: 1
    },
    statusAvailable: {
        extend: 'statusContainer',
        color: 'var(--jp-success-color0)'
    },
    statusNotAvailable: {
        extend: 'statusContainer',
        color: 'var(--jp-error-color1)'
    },
    statusReplicating: {
        extend: 'statusContainer',
        color: 'var(--jp-rucio-yellow-color)'
    },
    statusFetching: {
        extend: 'statusContainer',
        color: 'var(--jp-ui-font-color1)'
    },
    action: {
        fontSize: '9pt',
        color: 'var(--jp-rucio-primary-blue-color)',
        cursor: 'pointer'
    }
});
const _FileDIDItemDetails = ({ did, ...props }) => {
    const classes = useStyles();
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const { actions } = props;
    const { didPollingManager } = props;
    const fileDetails = (0,pullstate__WEBPACK_IMPORTED_MODULE_2__.useStoreState)(_stores_UIStore__WEBPACK_IMPORTED_MODULE_5__.UIStore, s => s.fileDetails[did]);
    const activeInstance = (0,pullstate__WEBPACK_IMPORTED_MODULE_2__.useStoreState)(_stores_UIStore__WEBPACK_IMPORTED_MODULE_5__.UIStore, s => s.activeInstance);
    const [pollingRequesterRef] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => new _utils_DIDPollingManager__WEBPACK_IMPORTED_MODULE_6__.PollingRequesterRef());
    const enablePolling = () => {
        didPollingManager.requestPolling(did, 'file', pollingRequesterRef);
    };
    const disablePolling = () => {
        didPollingManager.disablePolling(did, pollingRequesterRef);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        enablePolling();
        return () => {
            disablePolling();
        };
    }, []);
    const makeAvailable = () => {
        if (!activeInstance) {
            return;
        }
        actions === null || actions === void 0 ? void 0 : actions.makeFileAvailable(activeInstance.name, did).then(() => enablePolling()).catch(e => {
            console.error('Error making file available:', e);
            // The error 'e' is the rich ResponseError object from requestAPI
            if (e.response && e.response.status === 401) {
                setError('Authentication error. Perhaps you set an invalid credential?');
                return;
            }
            // The backend error message is directly available on e.error
            if (e.error) {
                setError(e.error);
            }
            else {
                // Fallback to the general error message if e.error is not present
                setError(e.message || 'An unknown error occurred.');
            }
        });
    };
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_4__.ServerConnection.makeSettings();
    const redirectorUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_3__.URLExt.join(settings.baseUrl, _const__WEBPACK_IMPORTED_MODULE_7__.EXTENSION_ID, 'open-replication-rule');
    const showReplicationRuleUrl = (activeInstance === null || activeInstance === void 0 ? void 0 : activeInstance.webuiUrl) && activeInstance.mode === 'replica'
        ? `${redirectorUrl}?namespace=${activeInstance === null || activeInstance === void 0 ? void 0 : activeInstance.name}&did=${did}`
        : undefined;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.container },
        !fileDetails && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.loading },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Spinning__WEBPACK_IMPORTED_MODULE_8__.Spinning, { className: `${classes.icon} material-icons` }, "hourglass_top"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: classes.statusText }, "Loading..."))),
        !!fileDetails && fileDetails.status === 'OK' && fileDetails.path && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(FileAvailable, { did: did, path: fileDetails.path, showReplicationRuleUrl: showReplicationRuleUrl })),
        !!fileDetails && fileDetails.status === 'NOT_AVAILABLE' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(FileNotAvailable, { onMakeAvailableClicked: makeAvailable, error: error })),
        !!fileDetails && fileDetails.status === 'REPLICATING' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(FileReplicating, { did: did, showReplicationRuleUrl: showReplicationRuleUrl })),
        !!fileDetails && fileDetails.status === 'FETCHING' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(FileFetching, { message: fileDetails.message })),
        !!fileDetails && fileDetails.status === 'STUCK' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(FileStuck, { onMakeAvailableClicked: (activeInstance === null || activeInstance === void 0 ? void 0 : activeInstance.mode) === 'download' ? makeAvailable : undefined, error: error, showReplicationRuleUrl: showReplicationRuleUrl })),
        !!fileDetails &&
            fileDetails.status === 'FAILED' &&
            (console.error('File details retrieval failed:', fileDetails),
                (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(FileNotAvailable, { onMakeAvailableClicked: makeAvailable, error: fileDetails.error || 'Failed to retrieve file details.' })))));
};
const FileAvailable = ({ did, path, showReplicationRuleUrl }) => {
    const classes = useStyles();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusAvailable },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.icon} material-icons` }, "check_circle"),
        showReplicationRuleUrl && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.clickableStatusText },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { href: showReplicationRuleUrl, target: "_blank", rel: "noreferrer", title: "Show replication rule" }, "Available"))),
        !showReplicationRuleUrl && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusText }, "Available")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.action },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_AddToNotebookPopover__WEBPACK_IMPORTED_MODULE_9__.AddToNotebookPopover, { did: did, type: "file" }, "Add to Notebook"))));
};
const FileNotAvailable = ({ onMakeAvailableClicked, error }) => {
    // Destructure error from props
    const classes = useStyles();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusNotAvailable },
        error ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.icon} material-icons` }, "error")) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.icon} material-icons` }, "lens")),
        error && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusText, style: { color: 'var(--jp-error-color1)' } }, error)),
        !error && react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusText }, "Not Available"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.action, onClick: onMakeAvailableClicked }, error ? 'Retry' : 'Make Available')));
};
const FileReplicating = ({ did, showReplicationRuleUrl }) => {
    const classes = useStyles();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusReplicating },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Spinning__WEBPACK_IMPORTED_MODULE_8__.Spinning, { className: `${classes.icon} material-icons` }, "hourglass_top"),
        showReplicationRuleUrl && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.clickableStatusText },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { href: showReplicationRuleUrl, target: "_blank", rel: "noreferrer", title: "Show replication rule" }, "Replicating files..."))),
        !showReplicationRuleUrl && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusText }, "Replicating files...")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.action },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_AddToNotebookPopover__WEBPACK_IMPORTED_MODULE_9__.AddToNotebookPopover, { did: did, type: "collection" }, "Add to Notebook"))));
};
const FileFetching = ({ message }) => {
    const classes = useStyles();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusFetching },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Spinning__WEBPACK_IMPORTED_MODULE_8__.Spinning, { className: `${classes.icon} material-icons` }, "hourglass_top"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusText }, message || 'Fetching replica information...')));
};
const FileStuck = ({ onMakeAvailableClicked, showReplicationRuleUrl, error }) => {
    const classes = useStyles();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusNotAvailable },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.icon} material-icons` }, "error"),
        error && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusText, style: { color: 'var(--jp-error-color1)' } }, error)),
        !error && showReplicationRuleUrl && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.clickableStatusText },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { href: showReplicationRuleUrl, target: "_blank", rel: "noreferrer", title: "Show replication rule" }, "Something went wrong"))),
        !error && !showReplicationRuleUrl && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.statusText }, "Something went wrong")),
        onMakeAvailableClicked && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.action, onClick: onMakeAvailableClicked }, "Make Available"))));
};
const FileDIDItemDetails = (0,_utils_DIDPollingManager__WEBPACK_IMPORTED_MODULE_6__.withPollingManager)((0,_utils_Actions__WEBPACK_IMPORTED_MODULE_10__.withRequestAPI)(_FileDIDItemDetails));


/***/ }),

/***/ "./lib/components/@Explore/InlineDropdown.js":
/*!***************************************************!*\
  !*** ./lib/components/@Explore/InlineDropdown.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InlineDropdown: () => (/* binding */ InlineDropdown)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */


const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    dropdown: {
        position: 'relative',
        display: 'inline-block'
    },
    dropdownTitle: {
        cursor: 'pointer'
    },
    dropdownContent: {
        display: 'none',
        position: 'absolute',
        marginTop: '8px',
        boxShadow: '0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23)',
        borderRadius: '4px',
        zIndex: 1,
        fontSize: '10pt',
        background: 'var(--jp-layout-color1)',
        color: 'var(--jp-ui-font-color1)'
    },
    dropdownActive: {
        minWidth: (props) => props.optionWidth || '150px',
        extend: 'dropdownContent',
        display: 'block'
    },
    dropdownListItem: {
        padding: '8px',
        width: 'auto',
        borderBottom: '1px solid var(--jp-border-color2)',
        cursor: 'pointer',
        '&:hover': {
            backgroundColor: 'var(--jp-layout-color2)'
        },
        '&:last-child': {
            borderBottom: 'none'
        }
    },
    icon: {
        fontSize: '16px',
        verticalAlign: 'middle'
    }
});
const InlineDropdown = ({ options, value, onItemSelected, optionWidth, ...props }) => {
    const classes = useStyles({ optionWidth });
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const currentOption = options.find(o => o.value === value);
    const clickTargetRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const handleClickOutside = (event) => {
        var _a;
        if (clickTargetRef &&
            !((_a = clickTargetRef.current) === null || _a === void 0 ? void 0 : _a.contains(event.target))) {
            setOpen(false);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    });
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: classes.dropdown, onClick: () => setOpen(!open), ref: clickTargetRef },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: classes.dropdownTitle, ...props },
            currentOption ? currentOption.title : '(select)',
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: `${classes.icon} material-icons` }, "arrow_drop_down")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: open ? classes.dropdownActive : classes.dropdownContent }, options.map(option => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.dropdownListItem, onClick: () => onItemSelected && onItemSelected(option.value), key: option.value }, option.title))))));
};


/***/ }),

/***/ "./lib/components/@Explore/ListAttachedFilesPopover.js":
/*!*************************************************************!*\
  !*** ./lib/components/@Explore/ListAttachedFilesPopover.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ListAttachedFilesPopover: () => (/* binding */ ListAttachedFilesPopover)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_popover__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-popover */ "webpack/sharing/consume/default/react-popover/react-popover");
/* harmony import */ var react_popover__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_popover__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_copy_to_clipboard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-copy-to-clipboard */ "webpack/sharing/consume/default/react-copy-to-clipboard/react-copy-to-clipboard");
/* harmony import */ var react_copy_to_clipboard__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_copy_to_clipboard__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_window__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-window */ "webpack/sharing/consume/default/react-window/react-window");
/* harmony import */ var react_window__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_window__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! pullstate */ "webpack/sharing/consume/default/pullstate/pullstate");
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(pullstate__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _stores_UIStore__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../stores/UIStore */ "./lib/stores/UIStore.js");
/* harmony import */ var _utils_Actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../utils/Actions */ "./lib/utils/Actions.js");
/* harmony import */ var _Spinning__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../Spinning */ "./lib/components/Spinning.js");
/* harmony import */ var _utils_Helpers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../utils/Helpers */ "./lib/utils/Helpers.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */










const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_3__.createUseStyles)({
    main: {
        width: '300px',
        background: 'var(--jp-layout-color1)',
        color: 'var(--jp-ui-font-color1)'
    },
    heading: {
        background: 'var(--jp-layout-color2)',
        color: 'var(--jp-ui-font-color2)',
        padding: '8px',
        borderBottom: '1px solid var(--jp-border-color2)',
        fontSize: '9pt',
        display: 'flex',
        flexDirection: 'row'
    },
    headingText: {
        textOverflow: 'ellipsis',
        overflow: 'hidden',
        whiteSpace: 'nowrap',
        flex: 1
    },
    content: {
        fontSize: '10pt',
        overflow: 'auto',
        maxHeight: '250px',
        '&.loading': {
            opacity: 0.4,
            pointerEvents: 'none'
        }
    },
    loading: {
        padding: '8px',
        boxSizing: 'border-box'
    },
    icon: {
        fontSize: '16px',
        verticalAlign: 'middle'
    },
    iconText: {
        fontSize: '9pt',
        verticalAlign: 'middle',
        paddingLeft: '4px'
    },
    headingCloseButton: {
        extend: 'icon',
        cursor: 'pointer'
    },
    listItem: {
        display: 'flex',
        padding: '8px',
        borderBottom: '1px solid var(--jp-border-color2)',
        flexDirection: 'row',
        fontSize: '9pt',
        alignItems: 'center',
        boxSizing: 'border-box',
        overflow: 'hidden'
    },
    textContainer: {
        flex: 1,
        textOverflow: 'ellipsis',
        overflow: 'hidden',
        whiteSpace: 'nowrap',
        cursor: 'pointer',
        '&:hover': {
            color: 'var(--jp-rucio-primary-blue-color)'
        },
        '& .copy': {
            display: 'none',
            fontSize: '12px'
        },
        '&:hover .copy': {
            display: 'inline'
        }
    },
    iconContainer: {
        lineHeight: 0,
        marginRight: '8px'
    },
    sizeContainer: {
        color: 'var(--jp-ui-font-color2)'
    },
    fileIcon: {
        extend: 'icon',
        color: '#66B100'
    },
    loadingIcon: {
        fontSize: '9pt',
        verticalAlign: 'middle'
    }
});
const ListAttachedFilesPopover = ({ children, did }) => {
    const classes = useStyles();
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [files, setFiles] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const activeInstance = (0,pullstate__WEBPACK_IMPORTED_MODULE_5__.useStoreState)(_stores_UIStore__WEBPACK_IMPORTED_MODULE_6__.UIStore, s => s.activeInstance);
    const escFunction = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((event) => {
        if (event.keyCode === 27) {
            setOpen(false);
        }
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        document.addEventListener('keydown', escFunction, false);
        return () => {
            document.removeEventListener('keydown', escFunction, false);
        };
    }, []);
    const Row = ({ index, style }) => {
        const file = files[index];
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ListItem, { style: style, did: file.did, size: file.size });
    };
    const popoverBody = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.main },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.heading },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.headingText },
                "Files of ",
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("b", null, did)),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.headingCloseButton} material-icons`, onClick: () => setOpen(false) }, "close")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.content },
            loading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.loading },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Spinning__WEBPACK_IMPORTED_MODULE_7__.Spinning, { className: `${classes.loadingIcon} material-icons` }, "hourglass_top"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: classes.iconText }, "Loading..."))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_window__WEBPACK_IMPORTED_MODULE_4__.FixedSizeList, { height: Math.min(250, 32 * files.length), itemCount: files.length, itemSize: 32, width: "100%" }, Row))));
    const loadAttachedFiles = () => {
        if (!activeInstance) {
            return;
        }
        setLoading(true);
        setFiles([]);
        _utils_Actions__WEBPACK_IMPORTED_MODULE_8__.actions
            .fetchAttachedFileDIDs(activeInstance.name, did)
            .then(result => setFiles(result))
            .catch(e => console.log(e)) // TODO handle error
            .finally(() => setLoading(false));
    };
    const openPopover = () => {
        setOpen(true);
        loadAttachedFiles();
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_popover__WEBPACK_IMPORTED_MODULE_1___default()), { enterExitTransitionDurationMs: 0, isOpen: open, preferPlace: "below", body: popoverBody, onOuterAction: () => setOpen(false) },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { onClick: openPopover }, children)));
};
const ListItem = ({ did, size, style }) => {
    const classes = useStyles();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.listItem, style: style },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.iconContainer },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.fileIcon} material-icons` }, "attachment")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_copy_to_clipboard__WEBPACK_IMPORTED_MODULE_2___default()), { text: did },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.textContainer },
                did,
                " ",
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: "material-icons copy" }, "file_copy"))),
        !!size && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.sizeContainer }, (0,_utils_Helpers__WEBPACK_IMPORTED_MODULE_9__.toHumanReadableSize)(size)))));
};


/***/ }),

/***/ "./lib/components/@Explore/ListScopesPopover.js":
/*!******************************************************!*\
  !*** ./lib/components/@Explore/ListScopesPopover.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ListScopesPopover: () => (/* binding */ ListScopesPopover)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_popover__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-popover */ "webpack/sharing/consume/default/react-popover/react-popover");
/* harmony import */ var react_popover__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_popover__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_window__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-window */ "webpack/sharing/consume/default/react-window/react-window");
/* harmony import */ var react_window__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_window__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! pullstate */ "webpack/sharing/consume/default/pullstate/pullstate");
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(pullstate__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _stores_UIStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../stores/UIStore */ "./lib/stores/UIStore.js");
/* harmony import */ var _utils_Actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../utils/Actions */ "./lib/utils/Actions.js");
/* harmony import */ var _Spinning__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Spinning */ "./lib/components/Spinning.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */








const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_2__.createUseStyles)({
    main: {
        width: '300px',
        background: 'var(--jp-layout-color1)',
        color: 'var(--jp-ui-font-color1)'
    },
    heading: {
        background: 'var(--jp-layout-color2)',
        color: 'var(--jp-ui-font-color2)',
        padding: '8px',
        borderBottom: '1px solid var(--jp-border-color2)',
        fontSize: '9pt',
        display: 'flex',
        flexDirection: 'row'
    },
    headingText: {
        textOverflow: 'ellipsis',
        overflow: 'hidden',
        whiteSpace: 'nowrap',
        flex: 1
    },
    errorText: {
        textOverflow: 'ellipsis',
        color: 'red',
        flex: 1
    },
    content: {
        fontSize: '10pt',
        overflow: 'auto',
        maxHeight: '250px',
        '&.loading': {
            opacity: 0.4,
            pointerEvents: 'none'
        }
    },
    loading: {
        padding: '8px',
        boxSizing: 'border-box'
    },
    icon: {
        fontSize: '16px',
        verticalAlign: 'middle'
    },
    iconText: {
        fontSize: '9pt',
        verticalAlign: 'middle',
        paddingLeft: '4px'
    },
    headingCloseButton: {
        extend: 'icon',
        cursor: 'pointer'
    },
    listItem: {
        display: 'flex',
        padding: '8px',
        borderBottom: '1px solid var(--jp-border-color2)',
        flexDirection: 'row',
        fontSize: '9pt',
        alignItems: 'center',
        boxSizing: 'border-box',
        overflow: 'hidden'
    },
    textContainer: {
        flex: 1,
        textOverflow: 'ellipsis',
        overflow: 'hidden',
        whiteSpace: 'nowrap',
        cursor: 'pointer',
        '&:hover': {
            color: 'var(--jp-rucio-primary-blue-color)'
        },
        '& .copy': {
            display: 'none',
            fontSize: '12px'
        },
        '&:hover .copy': {
            display: 'inline'
        }
    },
    iconContainer: {
        lineHeight: 0,
        marginRight: '8px'
    },
    scopeIcon: {
        extend: 'icon',
        color: 'var(--jp-layout-color4)'
    },
    loadingIcon: {
        fontSize: '9pt',
        verticalAlign: 'middle'
    }
});
const ListScopesPopover = ({ children, onScopeClicked }) => {
    const classes = useStyles();
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [scopes, setScopes] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [scopeResult, setScopeResult] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const activeInstance = (0,pullstate__WEBPACK_IMPORTED_MODULE_4__.useStoreState)(_stores_UIStore__WEBPACK_IMPORTED_MODULE_5__.UIStore, s => s.activeInstance);
    const escFunction = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((event) => {
        if (event.keyCode === 27) {
            setOpen(false);
        }
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        document.addEventListener('keydown', escFunction, false);
        return () => {
            document.removeEventListener('keydown', escFunction, false);
        };
    }, []);
    const onClick = (scope) => {
        setOpen(false);
        onScopeClicked === null || onScopeClicked === void 0 ? void 0 : onScopeClicked(scope);
    };
    const Row = ({ index, style }) => {
        const scope = scopes[index];
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ListItem, { style: style, scope: scope, onClick: () => onClick(scope) }));
    };
    const popoverBody = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.main },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.heading },
            scopeResult.length > 0 ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.errorText }, scopeResult.join(', '))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.headingText }, "Available scopes")),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.headingCloseButton} material-icons`, onClick: () => setOpen(false) }, "close")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.content },
            loading && scopes.length === 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.loading },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Spinning__WEBPACK_IMPORTED_MODULE_6__.Spinning, { className: `${classes.loadingIcon} material-icons` }, "hourglass_top"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: classes.iconText }, "Loading..."))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_window__WEBPACK_IMPORTED_MODULE_3__.FixedSizeList, { height: Math.min(250, 32 * scopes.length), itemCount: scopes.length, itemSize: 32, width: "100%" }, Row))));
    const loadScopes = () => {
        if (!activeInstance) {
            return;
        }
        setScopeResult([]);
        setScopes([]);
        setLoading(true);
        _utils_Actions__WEBPACK_IMPORTED_MODULE_7__.actions
            .fetchScopes(activeInstance.name)
            .then(result => {
            if (!result.success) {
                const errorMsg = result.error || 'Failed to fetch scopes';
                setScopeResult([errorMsg]);
                setLoading(false);
                return;
            }
            if (result && result.success && Array.isArray(result.scopes)) {
                // Correctly access the 'scopes' property which is a string array
                const scopesArray = result.scopes;
                // Now, sort the array. This works because scopesArray is a string[]
                scopesArray.sort((a, b) => a.localeCompare(b));
                // Update the state with the sorted array
                setScopes(scopesArray);
                console.log('Scopes fetched and sorted:', scopesArray);
            }
            else {
                // Handle API errors or unexpected data structure
                console.error('Failed to fetch scopes:', (result === null || result === void 0 ? void 0 : result.error) || 'Data is not in the expected format.');
            }
        })
            .catch(e => {
            console.error('An error occurred while fetching scopes:', e.error);
            const errorMsg = e.error || 'Unexpected error fetching scopes';
            setScopeResult([errorMsg]);
            setLoading(false);
            // Optionally, update the UI to show an error message
        })
            .finally(() => setLoading(false));
    };
    const openPopover = () => {
        setOpen(true);
        loadScopes();
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_popover__WEBPACK_IMPORTED_MODULE_1___default()), { enterExitTransitionDurationMs: 0, isOpen: open, preferPlace: "below", body: popoverBody, onOuterAction: () => setOpen(false) },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { onClick: openPopover }, children)));
};
const ListItem = ({ scope, style, onClick }) => {
    const classes = useStyles();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.listItem, style: style },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.iconContainer },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.scopeIcon} material-icons` }, "topic")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.textContainer, onClick: onClick }, scope)));
};


/***/ }),

/***/ "./lib/components/@Explore/MetadataFilterContainer.js":
/*!************************************************************!*\
  !*** ./lib/components/@Explore/MetadataFilterContainer.js ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MetadataFilterContainer: () => (/* binding */ MetadataFilterContainer)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Explore_MetadataFilterItem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/../@Explore/MetadataFilterItem */ "./lib/components/@Explore/MetadataFilterItem.js");



const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    metadataFilterContainer: {},
    addMetadataFilterButton: {
        marginTop: '4px',
        marginRight: '16px',
        marginLeft: '16px',
        width: 'fit-content',
        fontSize: '9pt',
        cursor: 'pointer',
        opacity: 0.5,
        '&:hover': {
            opacity: 1
        }
    },
    deleteFiltersButton: {
        marginTop: '4px',
        marginRight: '16px',
        marginLeft: '16px',
        width: 'fit-content',
        display: 'flex',
        alignItems: 'center',
        fontSize: '9pt',
        cursor: 'pointer',
        opacity: 0.5,
        '&:hover': {
            opacity: 1
        }
    },
    deleteFiltersIcon: {
        fontSize: '9pt',
        cursor: 'pointer',
        opacity: 0.5,
        '&:hover': {
            opacity: 1
        }
    }
});
const MetadataFilterContainer = ({ onKeyPress, metadataFilters, setMetadataFilters }) => {
    const classes = useStyles();
    const handleAddMetadataFilter = () => {
        setMetadataFilters([
            ...metadataFilters,
            { logic: 'And', key: '', operator: '=', value: '' }
        ]);
    };
    const handleDeleteMetadataFilter = (indexToDelete) => {
        setMetadataFilters(prev => {
            const newFilters = prev.filter((_, index) => index !== indexToDelete);
            if (indexToDelete === 0 && newFilters.length > 0) {
                newFilters[0] = { ...newFilters[0], logic: 'And' };
            }
            return newFilters;
        });
    };
    const handleDeleteAllMetadataFilters = () => {
        setMetadataFilters([]);
    };
    const handleFilterChange = (index, updatedFilter) => {
        setMetadataFilters(prev => {
            const newFilters = [...prev];
            newFilters[index] = updatedFilter;
            return newFilters;
        });
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.metadataFilterContainer },
        !metadataFilters.length && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.addMetadataFilterButton, onClick: handleAddMetadataFilter }, "+ Add metadata filter")),
        metadataFilters.map((filter, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Explore_MetadataFilterItem__WEBPACK_IMPORTED_MODULE_2__.MetadataFilterItem, { key: index, filter: filter, showBoolOperatorDropdown: index === 0, onDelete: () => handleDeleteMetadataFilter(index), onChange: updatedFilter => handleFilterChange(index, updatedFilter), onKeyPress: onKeyPress }))),
        !!metadataFilters.length && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.addMetadataFilterButton, onClick: handleAddMetadataFilter }, "+ Add filter rule")),
        !!metadataFilters.length && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.deleteFiltersButton, onClick: handleDeleteAllMetadataFilters },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.deleteFiltersIcon} material-icons` }, "delete"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { marginLeft: '8px' } }, "Delete filter")))));
};


/***/ }),

/***/ "./lib/components/@Explore/MetadataFilterItem.js":
/*!*******************************************************!*\
  !*** ./lib/components/@Explore/MetadataFilterItem.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MetadataFilterItem: () => (/* binding */ MetadataFilterItem)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_TextField__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components/TextField */ "./lib/components/TextField.js");



const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    metadataFilter: {
        display: 'flex',
        flexWrap: 'nowrap',
        flexDirection: 'row',
        alignItems: 'center',
        position: 'relative',
        padding: '4px 16px 0 16px'
    },
    where: {
        marginRight: '5pt'
    },
    select: {
        display: 'flex',
        alignSelf: 'stretch',
        color: 'var(--jp-ui-font-color1)',
        background: 'var(--jp-layout-color1)'
    },
    key: {
        flex: 1,
        minWidth: 0
    },
    value: {
        marginRight: '4px',
        flex: 1,
        minWidth: 0
    },
    deleteButton: {
        fontSize: '13pt',
        cursor: 'pointer',
        opacity: 0.5,
        '&:hover': {
            opacity: 1
        }
    },
    deleteIcon: {
        fontSize: '13pt',
        cursor: 'pointer',
        opacity: 0.5,
        '&:hover': {
            opacity: 1
        }
    }
});
const operators = ['=', '≠', '<', '>', '≤', '≥'];
const MetadataFilterItem = ({ filter, showBoolOperatorDropdown, onDelete, onChange, onKeyPress }) => {
    const classes = useStyles();
    const handleLogicChange = (e) => {
        onChange({ ...filter, logic: e.target.value });
    };
    const handleKeyChange = (e) => {
        onChange({ ...filter, key: e.target.value });
    };
    const handleOperatorChange = (e) => {
        onChange({ ...filter, operator: e.target.value });
    };
    const handleValueChange = (e) => {
        onChange({ ...filter, value: e.target.value });
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.metadataFilter },
        showBoolOperatorDropdown ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.where },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null, "Where"))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", { className: classes.select, value: filter.logic, onChange: handleLogicChange },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "And" }, "And"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "Or" }, "Or"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.key },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_TextField__WEBPACK_IMPORTED_MODULE_2__.TextField, { placeholder: "Key", value: filter.key, onChange: handleKeyChange, onKeyPress: onKeyPress })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", { className: classes.select, value: filter.operator, onChange: handleOperatorChange }, operators.map(op => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { key: op, value: op }, op)))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.value },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_TextField__WEBPACK_IMPORTED_MODULE_2__.TextField, { placeholder: "Value", value: filter.value, onChange: handleValueChange, onKeyPress: onKeyPress })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.deleteButton, onClick: onDelete },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.deleteIcon} material-icons` }, "delete"))));
};


/***/ }),

/***/ "./lib/components/@Notebook/NotebookAttachmentListItem.js":
/*!****************************************************************!*\
  !*** ./lib/components/@Notebook/NotebookAttachmentListItem.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NotebookAttachmentListItem: () => (/* binding */ NotebookAttachmentListItem)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! pullstate */ "webpack/sharing/consume/default/pullstate/pullstate");
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(pullstate__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Spinning__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Spinning */ "./lib/components/Spinning.js");
/* harmony import */ var _utils_Actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../utils/Actions */ "./lib/utils/Actions.js");
/* harmony import */ var _stores_UIStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../stores/UIStore */ "./lib/stores/UIStore.js");
/* harmony import */ var _utils_Helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../utils/Helpers */ "./lib/utils/Helpers.js");
/* harmony import */ var _stores_ExtensionStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../stores/ExtensionStore */ "./lib/stores/ExtensionStore.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */








const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    listItemContainer: {
        display: 'flex',
        flexDirection: 'row',
        borderBottom: '1px solid var(--jp-border-color2)',
        padding: '8px 16px 8px 16px',
        fontSize: '9pt'
    },
    listItemIconContainer: {
        paddingRight: '8px'
    },
    listItemContent: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'stretch',
        overflow: 'hidden',
        flex: 1
    },
    did: {
        textOverflow: 'ellipsis',
        overflow: 'hidden',
        whiteSpace: 'nowrap'
    },
    variableName: {
        overflowWrap: 'break-word',
        color: 'var(--jp-ui-font-color2)'
    },
    statusIcon: {
        marginTop: '2px',
        fontSize: '9pt'
    },
    availableIcon: {
        extend: 'statusIcon',
        color: 'var(--jp-success-color0)'
    },
    notAvailableIcon: {
        extend: 'statusIcon',
        color: 'var(--jp-error-color1)'
    },
    replicatingIcon: {
        extend: 'statusIcon',
        color: 'var(--jp-rucio-yellow-color)'
    },
    pendingInjectionIcon: {
        extend: 'statusIcon',
        color: 'var(--jp-success-color0)',
        opacity: 0.5
    },
    notResolvedIcon: {
        extend: 'statusIcon',
        color: 'var(--jp-ui-font-color2)'
    },
    actionContainer: {},
    clearButton: {
        alignItems: 'center',
        padding: '4px',
        lineHeight: 0,
        cursor: 'pointer'
    },
    clearIcon: {
        color: 'var(--jp-error-color1)',
        opacity: 0.5,
        fontSize: '16px',
        lineHeight: '24px',
        '&:hover': {
            opacity: 1
        }
    },
    action: {
        fontSize: '9pt',
        color: 'var(--jp-rucio-primary-blue-color)',
        cursor: 'pointer'
    }
});
const _NotebookAttachmentListItem = ({ attachment, status, ...props }) => {
    const classes = useStyles();
    const { actions } = props;
    const { did, type } = attachment;
    const fileDetails = (0,pullstate__WEBPACK_IMPORTED_MODULE_2__.useStoreState)(_stores_UIStore__WEBPACK_IMPORTED_MODULE_3__.UIStore, s => s.fileDetails[did]);
    const collectionDetails = (0,pullstate__WEBPACK_IMPORTED_MODULE_2__.useStoreState)(_stores_UIStore__WEBPACK_IMPORTED_MODULE_3__.UIStore, s => s.collectionDetails[did]);
    const activeInstance = (0,pullstate__WEBPACK_IMPORTED_MODULE_2__.useStoreState)(_stores_UIStore__WEBPACK_IMPORTED_MODULE_3__.UIStore, s => s.activeInstance);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!activeInstance) {
            return;
        }
        if (type === 'file') {
            actions.getFileDIDDetails(activeInstance.name, did);
        }
        else {
            actions.getCollectionDIDDetails(activeInstance.name, did);
        }
    }, []);
    const deleteAttachment = () => {
        _stores_ExtensionStore__WEBPACK_IMPORTED_MODULE_4__.ExtensionStore.update(s => {
            var _a;
            s.activeNotebookAttachment = (_a = s.activeNotebookAttachment) === null || _a === void 0 ? void 0 : _a.filter(a => a.did !== did);
        });
    };
    const collectionState = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
        return collectionDetails
            ? (0,_utils_Helpers__WEBPACK_IMPORTED_MODULE_5__.computeCollectionState)(collectionDetails)
            : undefined;
    }, [collectionDetails]);
    const shouldDisplayMakeAvailableButton = (() => {
        const isExtensionInDownloadMode = (activeInstance === null || activeInstance === void 0 ? void 0 : activeInstance.mode) === 'download';
        if (type === 'file') {
            return ((fileDetails === null || fileDetails === void 0 ? void 0 : fileDetails.status) === 'NOT_AVAILABLE' ||
                ((fileDetails === null || fileDetails === void 0 ? void 0 : fileDetails.status) === 'STUCK' && isExtensionInDownloadMode));
        }
        else if (type === 'collection') {
            return (collectionState === 'NOT_AVAILABLE' ||
                collectionState === 'PARTIALLY_AVAILABLE' ||
                (collectionState === 'STUCK' && isExtensionInDownloadMode));
        }
        return false;
    })();
    const makeAvailable = () => {
        if (!activeInstance) {
            return;
        }
        const { did, type } = attachment;
        if (type === 'file') {
            actions.makeFileAvailable(activeInstance.name, did);
        }
        else {
            actions.makeCollectionAvailable(activeInstance.name, did);
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.listItemContainer },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.listItemIconContainer },
            !fileDetails && !collectionDetails && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ResolverStatusIcon, { status: status })),
            !!fileDetails && type === 'file' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(FileStatusIcon, { status: fileDetails.status, resolverStatus: status })),
            !!collectionState && type === 'collection' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(CollectionStatusIcon, { status: collectionState, resolverStatus: status }))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.listItemContent },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.did }, attachment.did),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.variableName }, attachment.variableName),
            shouldDisplayMakeAvailableButton && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.action, onClick: makeAvailable }, "Make Available"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.actionContainer },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.clearButton, onClick: deleteAttachment },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.clearIcon} material-icons` }, "clear")))));
};
const ResolverStatusIcon = ({ status }) => {
    const classes = useStyles();
    switch (status) {
        case 'RESOLVING':
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Spinning__WEBPACK_IMPORTED_MODULE_6__.Spinning, { className: `${classes.statusIcon} material-icons` }, "hourglass_top"));
        case 'PENDING_INJECTION':
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.pendingInjectionIcon} material-icons` }, "lens"));
        case 'READY':
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.availableIcon} material-icons` }, "check_circle"));
        case 'FAILED':
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.notAvailableIcon} material-icons` }, "cancel"));
        default:
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.notResolvedIcon} material-icons` }, "lens"));
    }
};
const FileStatusIcon = ({ status, resolverStatus }) => {
    const classes = useStyles();
    switch (status) {
        case 'REPLICATING':
        case 'FETCHING':
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Spinning__WEBPACK_IMPORTED_MODULE_6__.Spinning, { className: `${classes.replicatingIcon} material-icons` }, "hourglass_top"));
        case 'NOT_AVAILABLE':
        case 'STUCK':
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.notAvailableIcon} material-icons` }, "lens"));
        default:
            return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ResolverStatusIcon, { status: resolverStatus });
    }
};
const CollectionStatusIcon = ({ status, resolverStatus }) => {
    const classes = useStyles();
    switch (status) {
        case 'REPLICATING':
        case 'FETCHING':
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Spinning__WEBPACK_IMPORTED_MODULE_6__.Spinning, { className: `${classes.replicatingIcon} material-icons` }, "hourglass_top"));
        case 'NOT_AVAILABLE':
        case 'STUCK':
        case 'PARTIALLY_AVAILABLE':
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.notAvailableIcon} material-icons` }, "lens"));
        default:
            return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ResolverStatusIcon, { status: resolverStatus });
    }
};
const NotebookAttachmentListItem = (0,_utils_Actions__WEBPACK_IMPORTED_MODULE_7__.withRequestAPI)(_NotebookAttachmentListItem);


/***/ }),

/***/ "./lib/components/@Notebook/NotebookTab.js":
/*!*************************************************!*\
  !*** ./lib/components/@Notebook/NotebookTab.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NotebookTab: () => (/* binding */ NotebookTab)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! pullstate */ "webpack/sharing/consume/default/pullstate/pullstate");
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(pullstate__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _stores_ExtensionStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../stores/ExtensionStore */ "./lib/stores/ExtensionStore.js");
/* harmony import */ var _NotebookAttachmentListItem__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./NotebookAttachmentListItem */ "./lib/components/@Notebook/NotebookAttachmentListItem.js");
/* harmony import */ var _HorizontalHeading__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../HorizontalHeading */ "./lib/components/HorizontalHeading.js");
/* harmony import */ var _utils_NotebookListener__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../utils/NotebookListener */ "./lib/utils/NotebookListener.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020-2021
 */







const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    container: {
        padding: '16px 0 16px 0'
    },
    messageContainer: {
        padding: '16px'
    }
});
const NotebookTab = () => {
    const classes = useStyles();
    const activeNotebookPanel = (0,pullstate__WEBPACK_IMPORTED_MODULE_2__.useStoreState)(_stores_ExtensionStore__WEBPACK_IMPORTED_MODULE_3__.ExtensionStore, s => s.activeNotebookPanel);
    const activeNotebookAttachments = (0,pullstate__WEBPACK_IMPORTED_MODULE_2__.useStoreState)(_stores_ExtensionStore__WEBPACK_IMPORTED_MODULE_3__.ExtensionStore, s => s.activeNotebookAttachment);
    const notebookStatusStore = (0,_utils_NotebookListener__WEBPACK_IMPORTED_MODULE_4__.useNotebookResolveStatusStore)();
    const notebookStatus = (activeNotebookPanel === null || activeNotebookPanel === void 0 ? void 0 : activeNotebookPanel.id)
        ? notebookStatusStore[activeNotebookPanel === null || activeNotebookPanel === void 0 ? void 0 : activeNotebookPanel.id]
        : null;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        !!activeNotebookPanel &&
            !!activeNotebookAttachments &&
            activeNotebookAttachments.length > 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.container }, activeNotebookAttachments.length > 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_HorizontalHeading__WEBPACK_IMPORTED_MODULE_5__.HorizontalHeading, { title: "Attached DIDs" }),
            activeNotebookAttachments.map(attachment => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_NotebookAttachmentListItem__WEBPACK_IMPORTED_MODULE_6__.NotebookAttachmentListItem, { key: attachment.did, attachment: attachment, status: notebookStatus
                    ? notebookStatus[attachment.did]
                    : undefined }))))))),
        !!activeNotebookPanel &&
            !!activeNotebookAttachments &&
            activeNotebookAttachments.length === 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.messageContainer }, "You have not attached any DID. Use the Explore menu to add a DID to this notebook.")),
        !activeNotebookPanel && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.messageContainer }, "Please open a Notebook."))));
};


/***/ }),

/***/ "./lib/components/@Settings/FilePickerPopover.js":
/*!*******************************************************!*\
  !*** ./lib/components/@Settings/FilePickerPopover.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectFileButtonTrailer: () => (/* binding */ SelectFileButtonTrailer)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_window__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-window */ "webpack/sharing/consume/default/react-window/react-window");
/* harmony import */ var react_window__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_window__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-virtualized-auto-sizer */ "webpack/sharing/consume/default/react-virtualized-auto-sizer/react-virtualized-auto-sizer");
/* harmony import */ var react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_popover__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-popover */ "webpack/sharing/consume/default/react-popover/react-popover");
/* harmony import */ var react_popover__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_popover__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_Actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../utils/Actions */ "./lib/utils/Actions.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */






const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    main: {
        width: '300px',
        background: 'var(--jp-layout-color1)',
        color: 'var(--jp-ui-font-color1)'
    },
    heading: {
        background: 'var(--jp-layout-color2)',
        color: 'var(--jp-ui-font-color2)',
        padding: '8px',
        borderBottom: '1px solid var(--jp-border-color2)',
        fontSize: '9pt'
    },
    content: {
        fontSize: '10pt',
        overflow: 'auto',
        height: '250px',
        '&.loading': {
            opacity: 0.4,
            pointerEvents: 'none'
        }
    },
    icon: {
        fontSize: '16px',
        verticalAlign: 'middle'
    },
    clickable: {
        cursor: 'pointer'
    },
    folderName: {
        verticalAlign: 'middle'
    },
    listItem: {
        display: 'flex',
        padding: '8px',
        borderBottom: '1px solid var(--jp-border-color2)',
        flexDirection: 'row',
        fontSize: '9pt',
        cursor: 'pointer',
        alignItems: 'center',
        boxSizing: 'border-box',
        '&:hover': {
            backgroundColor: 'var(--jp-layout-color2)'
        }
    },
    textContainer: {
        flex: 1,
        textOverflow: 'ellipsis',
        overflow: 'hidden',
        whiteSpace: 'nowrap'
    },
    iconContainer: {
        lineHeight: 0,
        marginRight: '8px',
        display: 'flex',
        alignItems: 'center'
    },
    fileIcon: {
        extend: 'icon',
        color: '#66B100'
    },
    dirIcon: {
        extend: 'icon',
        color: '#5DC0FD'
    },
    container: {
        padding: '8px 16px 8px 16px'
    },
    label: {
        margin: '4px 0 4px 0'
    },
    textFieldContainer: {
        margin: '8px 0 8px 0'
    },
    action: {
        cursor: 'pointer',
        color: 'var(--jp-rucio-primary-blue-color)'
    }
});
const _FilePickerPopover = ({ children, onFilePicked, ...props }) => {
    const { actions } = props;
    const classes = useStyles();
    const [path, setPath] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [directoryItems, setDirectoryItems] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [itemsCache, setItemsCache] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
    const openPopover = () => {
        setOpen(true);
        setPath([]);
        setDirectoryItems([]);
        setItemsCache({});
    };
    const itemsSortFunction = (a, b) => {
        if (a.type === b.type) {
            return a.name.toLowerCase() < b.name.toLowerCase() ? -1 : 1;
        }
        return a.type === 'dir' && b.type === 'file' ? -1 : 1;
    };
    const loadDirectoryItem = () => {
        const pathString = path.join('/');
        if (itemsCache[pathString]) {
            setDirectoryItems(itemsCache[pathString]);
        }
        else {
            setLoading(true);
            actions
                .listDirectory(pathString)
                .then(items => items.sort(itemsSortFunction))
                .then(items => {
                const newItemsCache = { ...itemsCache };
                newItemsCache[pathString] = items;
                setItemsCache(newItemsCache);
                setDirectoryItems(items);
            })
                .catch(() => setDirectoryItems([]))
                .finally(() => {
                setLoading(false);
            });
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(loadDirectoryItem, [path]);
    const moveToUpperDirectory = () => {
        const newPath = path.filter((p, i) => {
            return i < path.length - 1;
        });
        setPath(newPath);
    };
    const moveToHomeDirectory = () => {
        setPath([]);
    };
    const onKeyDown = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((event) => {
        if (event.keyCode === 27) {
            setOpen(false);
        }
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        document.addEventListener('keydown', onKeyDown, false);
        return () => {
            document.removeEventListener('keydown', onKeyDown, false);
        };
    }, []);
    const onItemClick = (item) => {
        if (item.type === 'dir') {
            setPath([...path, item.name]);
        }
        else {
            onFilePicked(item.path);
            setOpen(false);
        }
    };
    const Row = ({ index, style }) => {
        const item = directoryItems[index];
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ListItem, { style: style, directoryItem: item, key: item.path, onClick: () => onItemClick(item) }));
    };
    const popoverBody = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.main },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.heading },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: `material-icons ${classes.icon} ${classes.clickable}`, onClick: moveToHomeDirectory }, "home"),
            path.length === 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: classes.folderName }, "\u00A0 Home")),
            path.length >= 1 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: `material-icons ${classes.icon}` }, "navigate_next")),
            path.length >= 2 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: `material-icons ${classes.icon} ${classes.clickable}`, onClick: moveToUpperDirectory }, "more_horiz"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: `material-icons ${classes.icon}` }, "navigate_next"))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: classes.folderName }, path ? path[path.length - 1] : '')),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: `${classes.content} ${loading ? 'loading' : ''}` },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_3___default()), null, ({ height, width }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_window__WEBPACK_IMPORTED_MODULE_2__.FixedSizeList, { height: height, itemCount: directoryItems.length, itemSize: 32, width: width }, Row))))));
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_popover__WEBPACK_IMPORTED_MODULE_4___default()), { enterExitTransitionDurationMs: 0, isOpen: open, preferPlace: "above", body: popoverBody, onOuterAction: () => setOpen(false) },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { onClick: openPopover }, children)));
};
const ListItem = ({ directoryItem, onClick, style }) => {
    const classes = useStyles();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.listItem, onClick: onClick, style: style },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.iconContainer },
            directoryItem.type === 'file' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.fileIcon} material-icons` }, "attachment")),
            directoryItem.type === 'dir' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.dirIcon} material-icons` }, "folder"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.textContainer }, directoryItem.name)));
};
const FilePickerPopover = (0,_utils_Actions__WEBPACK_IMPORTED_MODULE_5__.withRequestAPI)(_FilePickerPopover);
const SelectFileButtonTrailer = ({ onFilePicked }) => {
    const classes = useStyles();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.iconContainer },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(FilePickerPopover, { onFilePicked: onFilePicked },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: `${classes.icon} ${classes.action} material-icons` }, "folder"))));
};


/***/ }),

/***/ "./lib/components/@Settings/OIDCAuth.js":
/*!**********************************************!*\
  !*** ./lib/components/@Settings/OIDCAuth.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   OIDCAuth: () => (/* binding */ OIDCAuth)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _TextField__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../TextField */ "./lib/components/TextField.js");
/* harmony import */ var _Spinning__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Spinning */ "./lib/components/Spinning.js");
/* harmony import */ var _FilePickerPopover__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./FilePickerPopover */ "./lib/components/@Settings/FilePickerPopover.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Giovanni Guerrieri, <giovanni.guerrieri@cern.ch>, 2025
 */





const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    container: {
        padding: '8px 16px 8px 16px'
    },
    label: {
        margin: '4px 0 4px 0'
    },
    textFieldContainer: {
        margin: '8px 0 8px 0'
    },
    warning: {
        margin: '8px 8px 16px 8px',
        color: 'var(--jp-ui-font-color2)',
        fontSize: '9pt'
    },
    loadingIcon: {
        fontSize: '10pt',
        verticalAlign: 'middle'
    },
    loadingContainer: {
        padding: '0 8px 0 8px',
        display: 'flex',
        alignItems: 'center'
    }
});
const OIDCAuth = ({ params = { token: '' }, loading, onAuthParamsChange }) => {
    const classes = useStyles();
    const onTokenPathChange = (token_path) => {
        onAuthParamsChange({ ...params, token_path: token_path !== null && token_path !== void 0 ? token_path : '' });
    };
    const loadingSpinner = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.loadingContainer },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Spinning__WEBPACK_IMPORTED_MODULE_2__.Spinning, { className: `${classes.loadingIcon} material-icons` }, "hourglass_top")));
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.container },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.warning },
                "Upon authentication with the Rucio CLI, the token is usually stored in the path corresponding to ",
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("code", null, "auth_token_file_path"),
                " ",
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { style: { color: '#3366cc' }, href: "https://rucio.github.io/documentation/operator/configuration_parameters/#client_config", target: "_blank" }, "in your Rucio configuration"),
                ". ",
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("br", null),
                "If you do not know where your token is, please check with your system administrator."),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.textFieldContainer },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_TextField__WEBPACK_IMPORTED_MODULE_3__.TextField, { placeholder: "Token file path", 
                    // This could be a file path or the token itself,
                    // but we chose not to include the raw token for security reasons
                    value: params.token_path, onChange: e => onTokenPathChange(e.target.value), disabled: loading, after: loading ? (loadingSpinner) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_FilePickerPopover__WEBPACK_IMPORTED_MODULE_4__.SelectFileButtonTrailer, { onFilePicked: path => onTokenPathChange(path) })) })))));
};


/***/ }),

/***/ "./lib/components/@Settings/SettingsTab.js":
/*!*************************************************!*\
  !*** ./lib/components/@Settings/SettingsTab.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SettingsTab: () => (/* binding */ SettingsTab)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_select__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-select */ "webpack/sharing/consume/default/react-select/react-select");
/* harmony import */ var react_select__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_select__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! pullstate */ "webpack/sharing/consume/default/pullstate/pullstate");
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(pullstate__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _stores_UIStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../stores/UIStore */ "./lib/stores/UIStore.js");
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../Button */ "./lib/components/Button.js");
/* harmony import */ var _utils_Actions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../utils/Actions */ "./lib/utils/Actions.js");
/* harmony import */ var _UserPassAuth__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./UserPassAuth */ "./lib/components/@Settings/UserPassAuth.js");
/* harmony import */ var _X509Auth__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./X509Auth */ "./lib/components/@Settings/X509Auth.js");
/* harmony import */ var _X509ProxyAuth__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./X509ProxyAuth */ "./lib/components/@Settings/X509ProxyAuth.js");
/* harmony import */ var _OIDCAuth__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./OIDCAuth */ "./lib/components/@Settings/OIDCAuth.js");
/* harmony import */ var _HorizontalHeading__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../HorizontalHeading */ "./lib/components/HorizontalHeading.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020-2021
 */












const getEnabledAuthTypes = (instance) => [
    { label: 'OpenID Connect', value: 'oidc' },
    { label: 'X.509 User Certificate', value: 'x509' },
    { label: 'X.509 Proxy Certificate', value: 'x509_proxy' },
    { label: 'Username & Password', value: 'userpass' }
].filter(x => !!x);
const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    content: {
        height: '100%',
        display: 'flex',
        overflow: 'auto',
        flexDirection: 'column'
    },
    scrollable: {
        flex: 1,
        paddingTop: '8px'
    },
    container: {
        padding: '8px 16px 8px 16px'
    },
    buttonContainer: {
        extend: 'container'
    },
    validateButton: {
        marginTop: '8px',
        extend: 'container'
    },
    validationMessage: {
        extend: 'subtitle',
        marginTop: '8px',
        margin: '8px 8px 16px 8px'
    },
    instanceName: {
        fontSize: '16pt'
    },
    formControl: {
        marginTop: '8px'
    },
    formItem: {
        marginBottom: '16px'
    },
    label: {
        margin: '4px 0 4px 0'
    },
    textFieldContainer: {
        margin: '8px 0 8px 0'
    },
    subtitle: {
        color: 'var(--jp-ui-font-color2)',
        fontSize: '9pt'
    },
    warning: {
        extend: 'subtitle',
        margin: '8px 8px 16px 8px'
    },
    icon: {
        fontSize: '10pt',
        verticalAlign: 'middle'
    },
    iconText: {
        verticalAlign: 'middle',
        paddingLeft: '4px'
    },
    hidden: {
        display: 'none'
    },
    action: {
        cursor: 'pointer',
        color: 'var(--jp-rucio-primary-blue-color)',
        fontSize: '9pt'
    },
    buttonSavedAcknowledgement: {
        background: '#689f38',
        color: '#ffffff',
        '&:hover': {
            color: '#ffffff',
            background: '#79C13A'
        }
    },
    buttonSavedError: {
        background: '#f44336',
        color: '#ffffff',
        '&:hover': {
            color: '#ffffff',
            background: '#DC3125'
        }
    },
    buttonPurgedAcknowledgement: {
        extend: 'purgeButton',
        background: 'var(--jp-error-color1)',
        color: '#ffffff',
        '&:hover': {
            background: 'var(--jp-error-color1)'
        }
    },
    purgeButton: {
        marginTop: '16px'
    }
});
const _Settings = props => {
    const { actions } = props;
    const classes = useStyles();
    const activeInstance = (0,pullstate__WEBPACK_IMPORTED_MODULE_3__.useStoreState)(_stores_UIStore__WEBPACK_IMPORTED_MODULE_4__.UIStore, s => s.activeInstance);
    const activeAuthType = (0,pullstate__WEBPACK_IMPORTED_MODULE_3__.useStoreState)(_stores_UIStore__WEBPACK_IMPORTED_MODULE_4__.UIStore, s => s.activeAuthType);
    const instances = (0,pullstate__WEBPACK_IMPORTED_MODULE_3__.useStoreState)(_stores_UIStore__WEBPACK_IMPORTED_MODULE_4__.UIStore, s => s.instances) || [];
    const [selectedInstance, setSelectedInstance] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(activeInstance === null || activeInstance === void 0 ? void 0 : activeInstance.name);
    const selectedInstanceObject = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => instances.find(i => i.name === selectedInstance), [instances, selectedInstance]);
    const authTypeOptions = selectedInstanceObject
        ? getEnabledAuthTypes(selectedInstanceObject)
        : [];
    const authTypeDefaultValue = activeAuthType
        ? authTypeOptions.find(o => o.value === activeAuthType)
        : undefined;
    const [selectedAuthType, setSelectedAuthType] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(activeAuthType);
    const [rucioUserpassAuthCredentials, setRucioUserpassAuthCredentials] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const [rucioX509AuthCredentials, setRucioX509AuthCredentials] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const [rucioX509ProxyAuthCredentials, setRucioX509ProxyAuthCredentials] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const [rucioOIDCAuthCredentials, setRucioOIDCAuthCredentials] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const [credentialsLoading, setCredentialsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [showSaved, setShowSaved] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [showAdvancedSettings, setShowAdvancedSettings] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [purgingCache, setPurgingCache] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [showCachePurged, setShowCachePurged] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [validationResult, setValidationResult] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const instanceOptions = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => instances === null || instances === void 0 ? void 0 : instances.map(i => ({ label: i.displayName, value: i.name })), [instances]);
    const setActiveInstance = (instanceName, authType) => {
        _stores_UIStore__WEBPACK_IMPORTED_MODULE_4__.UIStore.update(s => {
            var _a;
            if (((_a = s.activeInstance) === null || _a === void 0 ? void 0 : _a.name) !== instanceName) {
                (0,_stores_UIStore__WEBPACK_IMPORTED_MODULE_4__.resetRucioCaches)();
                const instance = instances.find(i => i.name === instanceName);
                s.activeInstance = instance;
            }
            if (s.activeAuthType !== authType) {
                s.activeAuthType = authType;
            }
        });
        return actions
            .postActiveInstance(instanceName, authType)
            .catch(e => console.log(e));
    };
    const saveSettings = async () => {
        if (!selectedInstance) {
            return;
        }
        setLoading(true);
        setValidationResult(null);
        setShowSaved(false);
        const promises = [];
        let putAuthConfigSuccess = false;
        let putAuthConfigError = null;
        if (selectedAuthType) {
            const rucioAuthCredentials = (() => {
                switch (selectedAuthType) {
                    case 'userpass':
                        return rucioUserpassAuthCredentials;
                    case 'x509':
                        return rucioX509AuthCredentials;
                    case 'x509_proxy':
                        return rucioX509ProxyAuthCredentials;
                    case 'oidc':
                        return rucioOIDCAuthCredentials;
                    default:
                        return null;
                }
            })();
            if (!rucioAuthCredentials) {
                setValidationResult('❌ Missing authentication credentials');
                setLoading(false);
                setTimeout(() => {
                    setShowSaved(false);
                    setValidationResult(null); // revert to default state
                }, 2000);
                return;
            }
            promises.push(actions
                .putAuthConfig(selectedInstance, selectedAuthType, rucioAuthCredentials)
                .then(response => {
                putAuthConfigSuccess = true;
                if (response.lifetime) {
                    const expiration = new Date(response.lifetime);
                    const now = new Date();
                    const diffMs = expiration.getTime() - now.getTime(); // milliseconds
                    const diffSec = Math.floor(diffMs / 1000);
                    const diffMin = Math.floor(diffSec / 60);
                    const diffHr = Math.floor(diffMin / 60);
                    const remainingMin = diffMin % 60;
                    let timeLeftStr = '';
                    if (diffMs <= 0) {
                        timeLeftStr = 'Token has expired';
                    }
                    else if (diffHr > 0) {
                        timeLeftStr = `${diffHr}h ${remainingMin}m`;
                    }
                    else {
                        timeLeftStr = `${diffMin} minute${diffMin !== 1 ? 's' : ''}`;
                    }
                    setValidationResult(`✅ Connection successful!\n🕙 Time left: ${timeLeftStr}`);
                }
                else {
                    setValidationResult('✅ Connection successful!');
                }
            })
                .catch(err => {
                // Safe fallback values
                const errorMessage = err.error || err.message || 'Unknown error';
                const exceptionClass = err.exception_class;
                const exceptionMessage = err.exception_message;
                putAuthConfigError = `${errorMessage}${exceptionClass ? ` (Exception Class: ${exceptionClass})` : ''}${exceptionMessage && exceptionMessage !== errorMessage
                    ? ` (Exception Message: ${exceptionMessage})`
                    : ''}`;
            }));
        }
        if (selectedInstance && selectedAuthType) {
            promises.push(setActiveInstance(selectedInstance, selectedAuthType));
        }
        try {
            await Promise.all(promises);
            if (putAuthConfigSuccess) {
                setShowSaved(true);
                setTimeout(() => {
                    setShowSaved(false);
                    setValidationResult(null); // revert to default state
                }, 3000);
            }
            else if (putAuthConfigError) {
                setValidationResult(`❌ ${putAuthConfigError}`);
                setTimeout(() => {
                    setShowSaved(false);
                    setValidationResult(null); // revert to default state
                }, 5000);
            }
        }
        catch (err) {
            setValidationResult(`❌ Unexpected error: ${err instanceof Error ? err.message : String(err)}`);
        }
        finally {
            setLoading(false);
        }
    };
    const reloadAuthConfig = () => {
        if (!selectedInstance) {
            return;
        }
        setCredentialsLoading(true);
        if (selectedAuthType === 'userpass') {
            actions
                .fetchAuthConfig(selectedInstance, selectedAuthType)
                .then(c => {
                setRucioUserpassAuthCredentials(c);
            })
                .catch(err => {
                console.error('Error fetching userpass auth config:', err);
                setRucioUserpassAuthCredentials(undefined);
            })
                .finally(() => {
                setCredentialsLoading(false);
            });
        }
        else if (selectedAuthType === 'x509') {
            actions
                .fetchAuthConfig(selectedInstance, selectedAuthType)
                .then(c => {
                setRucioX509AuthCredentials(c);
            })
                .catch(err => {
                console.error('Error fetching X.509 auth config:', err);
                setRucioX509AuthCredentials(undefined);
            })
                .finally(() => {
                setCredentialsLoading(false);
            });
        }
        else if (selectedAuthType === 'x509_proxy') {
            actions
                .fetchAuthConfig(selectedInstance, selectedAuthType)
                .then(c => setRucioX509ProxyAuthCredentials(c))
                .catch(err => {
                console.error('Error fetching x509_proxy auth config:', err);
                setRucioX509ProxyAuthCredentials(undefined);
            })
                .finally(() => setCredentialsLoading(false));
        }
        else if (selectedAuthType === 'oidc') {
            actions
                .fetchAuthConfig(selectedInstance, selectedAuthType)
                .then(c => {
                setRucioOIDCAuthCredentials(c);
            })
                .catch(err => {
                console.error('Error fetching OIDC auth config:', err);
                setRucioOIDCAuthCredentials(undefined);
            })
                .finally(() => {
                setCredentialsLoading(false);
            });
        }
    };
    const purgeCache = () => {
        setShowCachePurged(false);
        setPurgingCache(true);
        actions
            .purgeCache()
            .then(() => {
            setShowCachePurged(true);
            setTimeout(() => setShowCachePurged(false), 3000);
        })
            .finally(() => setPurgingCache(false));
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(reloadAuthConfig, [selectedInstance, selectedAuthType]);
    const settingsComplete = selectedInstance && selectedAuthType;
    const selectStyles = {
        control: (provided, state) => ({
            ...provided,
            borderRadius: 0,
            borderColor: 'var(--jp-border-color1)',
            background: 'var(--jp-layout-color1)'
        }),
        singleValue: (provided, state) => ({
            ...provided,
            color: 'var(--jp-ui-font-color1)'
        }),
        menu: (provided, state) => ({
            ...provided,
            background: 'var(--jp-layout-color1)',
            color: 'var(--jp-ui-font-color1)'
        }),
        option: (provided, { isFocused, isSelected }) => ({
            ...provided,
            background: isFocused
                ? isSelected
                    ? provided.background
                    : 'var(--jp-layout-color2)'
                : provided.background,
            ':active': {
                ...provided[':active'],
                background: isSelected ? provided.background : 'var(--jp-layout-color2)'
            }
        })
    };
    const instanceDefaultValue = activeInstance
        ? { label: activeInstance.displayName, value: activeInstance.name }
        : null;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.content },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.scrollable },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.container },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.formItem },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.label }, "Active Instance"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_select__WEBPACK_IMPORTED_MODULE_2___default()), { className: classes.formControl, options: instanceOptions, styles: selectStyles, defaultValue: instanceDefaultValue, onChange: (value) => setSelectedInstance(value.value) })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.formItem },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.label }, "Authentication"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_select__WEBPACK_IMPORTED_MODULE_2___default()), { className: classes.formControl, options: authTypeOptions, styles: selectStyles, defaultValue: authTypeDefaultValue, onChange: (value) => setSelectedAuthType(value.value) }))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: selectedInstance && selectedAuthType === 'oidc'
                        ? ''
                        : classes.hidden },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_HorizontalHeading__WEBPACK_IMPORTED_MODULE_5__.HorizontalHeading, { title: "OIDC Token" }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_OIDCAuth__WEBPACK_IMPORTED_MODULE_6__.OIDCAuth, { loading: credentialsLoading, params: rucioOIDCAuthCredentials, onAuthParamsChange: v => setRucioOIDCAuthCredentials(v) })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: selectedInstance && selectedAuthType === 'userpass'
                        ? ''
                        : classes.hidden },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_HorizontalHeading__WEBPACK_IMPORTED_MODULE_5__.HorizontalHeading, { title: "Username & Password" }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_UserPassAuth__WEBPACK_IMPORTED_MODULE_7__.UserPassAuth, { loading: credentialsLoading, params: rucioUserpassAuthCredentials, onAuthParamsChange: v => setRucioUserpassAuthCredentials(v) })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: selectedInstance && selectedAuthType === 'x509'
                        ? ''
                        : classes.hidden },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_HorizontalHeading__WEBPACK_IMPORTED_MODULE_5__.HorizontalHeading, { title: "X.509 User Certificate" }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_X509Auth__WEBPACK_IMPORTED_MODULE_8__.X509Auth, { loading: credentialsLoading, params: rucioX509AuthCredentials, onAuthParamsChange: v => setRucioX509AuthCredentials(v) })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: selectedInstance && selectedAuthType === 'x509_proxy'
                        ? ''
                        : classes.hidden },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_HorizontalHeading__WEBPACK_IMPORTED_MODULE_5__.HorizontalHeading, { title: "X.509 Proxy Certificate" }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_X509ProxyAuth__WEBPACK_IMPORTED_MODULE_9__.X509ProxyAuth, { loading: credentialsLoading, params: rucioX509ProxyAuthCredentials, onAuthParamsChange: v => setRucioX509ProxyAuthCredentials(v) }))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: showAdvancedSettings ? undefined : classes.hidden },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_HorizontalHeading__WEBPACK_IMPORTED_MODULE_5__.HorizontalHeading, { title: "Advanced Settings" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.container },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.formItem },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.textFieldContainer },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.label }, "Purge cache"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.subtitle }, "Remove all caches, including search results and DID paths."),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Button__WEBPACK_IMPORTED_MODULE_10__.Button, { block: true, onClick: purgeCache, disabled: purgingCache, outlineColor: "var(--jp-error-color1)", color: !purgingCache && showCachePurged
                                    ? '#FFFFFF'
                                    : 'var(--jp-error-color1)', className: !purgingCache && showCachePurged
                                    ? classes.buttonPurgedAcknowledgement
                                    : classes.purgeButton },
                                !purgingCache && !showCachePurged && react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, "Purge Cache"),
                                purgingCache && react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, "Purging..."),
                                !purgingCache && showCachePurged && react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, "Purged!")))))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.container },
                !showAdvancedSettings && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.action, onClick: () => setShowAdvancedSettings(true) }, "Show Advanced Settings")),
                showAdvancedSettings && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.action, onClick: () => setShowAdvancedSettings(false) }, "Hide Advanced Settings")))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.buttonContainer },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Button__WEBPACK_IMPORTED_MODULE_10__.Button, { block: true, onClick: saveSettings, disabled: !settingsComplete || loading, outlineColor: showSaved ? '#689f38' : undefined, color: showSaved ? '#FFFFFF' : undefined, className: showSaved
                    ? classes.buttonSavedAcknowledgement
                    : (validationResult === null || validationResult === void 0 ? void 0 : validationResult.startsWith('❌'))
                        ? classes.buttonSavedError
                        : undefined }, loading ? (selectedAuthType === 'oidc' ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, "Validating...")) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, "Saving..."))) : showSaved ? (selectedAuthType === 'oidc' ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, "Validated!")) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, "Saved!"))) : (validationResult === null || validationResult === void 0 ? void 0 : validationResult.startsWith('❌')) ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, "Error!")) : selectedAuthType === 'oidc' ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, "Validate")) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, "Save Settings"))),
            validationResult && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.validationMessage }, validationResult.split('\n').map((line, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { key: index },
                line,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("br", null)))))))));
};
const SettingsTab = (0,_utils_Actions__WEBPACK_IMPORTED_MODULE_11__.withRequestAPI)(_Settings);


/***/ }),

/***/ "./lib/components/@Settings/UserPassAuth.js":
/*!**************************************************!*\
  !*** ./lib/components/@Settings/UserPassAuth.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UserPassAuth: () => (/* binding */ UserPassAuth)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _TextField__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../TextField */ "./lib/components/TextField.js");
/* harmony import */ var _Spinning__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Spinning */ "./lib/components/Spinning.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */




const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    container: {
        padding: '8px 16px 8px 16px'
    },
    label: {
        margin: '4px 0 4px 0'
    },
    textFieldContainer: {
        margin: '8px 0 8px 0'
    },
    warning: {
        margin: '8px 8px 16px 8px',
        color: 'var(--jp-ui-font-color2)',
        fontSize: '9pt'
    },
    loadingIcon: {
        fontSize: '10pt',
        verticalAlign: 'middle'
    },
    loadingContainer: {
        padding: '0 8px 0 8px',
        display: 'flex',
        alignItems: 'center'
    }
});
const UserPassAuth = ({ params = { username: '', password: '', account: '' }, loading, onAuthParamsChange }) => {
    const classes = useStyles();
    const onUsernameChange = (username) => {
        onAuthParamsChange({ ...params, username });
    };
    const onPasswordChange = (password) => {
        onAuthParamsChange({ ...params, password });
    };
    const onAccountChange = (account) => {
        onAuthParamsChange({ ...params, account });
    };
    const loadingSpinner = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.loadingContainer },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Spinning__WEBPACK_IMPORTED_MODULE_2__.Spinning, { className: `${classes.loadingIcon} material-icons` }, "hourglass_top")));
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.container },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.textFieldContainer },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.label }, "Username"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_TextField__WEBPACK_IMPORTED_MODULE_3__.TextField, { placeholder: "Username", value: params.username, onChange: e => onUsernameChange(e.target.value), disabled: loading, after: loading ? loadingSpinner : undefined })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.textFieldContainer },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.label }, "Password"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_TextField__WEBPACK_IMPORTED_MODULE_3__.TextField, { placeholder: "Password", type: "password", value: params.password, onChange: e => onPasswordChange(e.target.value), disabled: loading, after: loading ? loadingSpinner : undefined })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.warning }, "Your password will be stored in plain text inside your user directory."),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.textFieldContainer },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.label }, "Account"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_TextField__WEBPACK_IMPORTED_MODULE_3__.TextField, { placeholder: "Account", value: params.account, onChange: e => onAccountChange(e.target.value), disabled: loading, after: loading ? loadingSpinner : undefined })))));
};


/***/ }),

/***/ "./lib/components/@Settings/X509Auth.js":
/*!**********************************************!*\
  !*** ./lib/components/@Settings/X509Auth.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   X509Auth: () => (/* binding */ X509Auth)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _TextField__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../TextField */ "./lib/components/TextField.js");
/* harmony import */ var _Spinning__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Spinning */ "./lib/components/Spinning.js");
/* harmony import */ var _FilePickerPopover__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./FilePickerPopover */ "./lib/components/@Settings/FilePickerPopover.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */





const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    container: {
        padding: '8px 16px 8px 16px'
    },
    label: {
        margin: '4px 0 4px 0'
    },
    textFieldContainer: {
        margin: '8px 0 8px 0'
    },
    warning: {
        margin: '8px 8px 16px 8px',
        color: 'var(--jp-ui-font-color2)',
        fontSize: '9pt'
    },
    icon: {
        fontSize: '10pt',
        verticalAlign: 'middle'
    },
    iconContainer: {
        padding: '0 8px 0 0',
        display: 'flex',
        alignItems: 'center'
    },
    action: {
        cursor: 'pointer',
        color: 'var(--jp-rucio-primary-blue-color)'
    }
});
const X509Auth = ({ params = { certificate: '', key: '', account: '' }, loading, onAuthParamsChange }) => {
    const classes = useStyles();
    const onCertPathChange = (path) => {
        onAuthParamsChange({ ...params, certificate: path });
    };
    const onKeyPathChange = (path) => {
        onAuthParamsChange({ ...params, key: path });
    };
    const onAccountChange = (account) => {
        onAuthParamsChange({ ...params, account });
    };
    const loadingSpinner = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.iconContainer },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Spinning__WEBPACK_IMPORTED_MODULE_2__.Spinning, { className: `${classes.icon} material-icons` }, "hourglass_top")));
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.container },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.textFieldContainer },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.label }, "Certificate file path"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_TextField__WEBPACK_IMPORTED_MODULE_3__.TextField, { placeholder: "Path to certificate file", value: params.certificate, onChange: e => onCertPathChange(e.target.value), disabled: loading, after: loading ? (loadingSpinner) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_FilePickerPopover__WEBPACK_IMPORTED_MODULE_4__.SelectFileButtonTrailer, { onFilePicked: path => onCertPathChange(path) })) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.textFieldContainer },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.label }, "Key file path"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_TextField__WEBPACK_IMPORTED_MODULE_3__.TextField, { placeholder: "Path to key file", value: params.key, onChange: e => onKeyPathChange(e.target.value), disabled: loading, after: loading ? (loadingSpinner) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_FilePickerPopover__WEBPACK_IMPORTED_MODULE_4__.SelectFileButtonTrailer, { onFilePicked: path => onKeyPathChange(path) })) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.warning }, "Enter the private key path if the certificate file does not include it. Passphrase-protected certificate is not supported."),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.textFieldContainer },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.label }, "Account"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_TextField__WEBPACK_IMPORTED_MODULE_3__.TextField, { placeholder: "Account", value: params.account, onChange: e => onAccountChange(e.target.value), disabled: loading, after: loading ? loadingSpinner : undefined })))));
};


/***/ }),

/***/ "./lib/components/@Settings/X509ProxyAuth.js":
/*!***************************************************!*\
  !*** ./lib/components/@Settings/X509ProxyAuth.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   X509ProxyAuth: () => (/* binding */ X509ProxyAuth)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _TextField__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../TextField */ "./lib/components/TextField.js");
/* harmony import */ var _Spinning__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Spinning */ "./lib/components/Spinning.js");
/* harmony import */ var _FilePickerPopover__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./FilePickerPopover */ "./lib/components/@Settings/FilePickerPopover.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */





const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    container: {
        padding: '8px 16px 8px 16px'
    },
    label: {
        margin: '4px 0 4px 0'
    },
    textFieldContainer: {
        margin: '8px 0 8px 0'
    },
    warning: {
        margin: '8px 8px 16px 8px',
        color: 'var(--jp-ui-font-color2)',
        fontSize: '9pt'
    },
    icon: {
        fontSize: '10pt',
        verticalAlign: 'middle'
    },
    iconContainer: {
        padding: '0 8px 0 0',
        display: 'flex',
        alignItems: 'center'
    },
    action: {
        cursor: 'pointer',
        color: 'var(--jp-rucio-primary-blue-color)'
    }
});
const X509ProxyAuth = ({ params = { proxy: '', account: '' }, loading, onAuthParamsChange }) => {
    const classes = useStyles();
    const onProxyPathChange = (path) => {
        onAuthParamsChange({ ...params, proxy: path });
    };
    const onAccountChange = (account) => {
        onAuthParamsChange({ ...params, account });
    };
    const loadingSpinner = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.iconContainer },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Spinning__WEBPACK_IMPORTED_MODULE_2__.Spinning, { className: `${classes.icon} material-icons` }, "hourglass_top")));
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.container },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.textFieldContainer },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.label }, "Proxy file path"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_TextField__WEBPACK_IMPORTED_MODULE_3__.TextField, { placeholder: "Path to proxy PEM file", value: params.proxy, onChange: e => onProxyPathChange(e.target.value), disabled: loading, after: loading ? (loadingSpinner) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_FilePickerPopover__WEBPACK_IMPORTED_MODULE_4__.SelectFileButtonTrailer, { onFilePicked: path => onProxyPathChange(path) })) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.textFieldContainer },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.label }, "Account"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_TextField__WEBPACK_IMPORTED_MODULE_3__.TextField, { placeholder: "Account", value: params.account, onChange: e => onAccountChange(e.target.value), disabled: loading, after: loading ? loadingSpinner : undefined })))));
};


/***/ }),

/***/ "./lib/components/@Uploads/UploadJobListItem.js":
/*!******************************************************!*\
  !*** ./lib/components/@Uploads/UploadJobListItem.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UploadJobListItem: () => (/* binding */ UploadJobListItem)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Spinning__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Spinning */ "./lib/components/Spinning.js");
/* harmony import */ var _utils_Actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../utils/Actions */ "./lib/utils/Actions.js");
/* harmony import */ var _const__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../const */ "./lib/const.js");
/* harmony import */ var _widgets_UploadLogViewerWidget__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../widgets/UploadLogViewerWidget */ "./lib/widgets/UploadLogViewerWidget.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020-2021
 */






const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    listItemContainer: {
        display: 'flex',
        flexDirection: 'row',
        borderBottom: '1px solid var(--jp-border-color2)',
        padding: '8px 16px 8px 16px',
        fontSize: '9pt'
    },
    listItemIconContainer: {
        paddingRight: '8px'
    },
    listItemContent: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'stretch',
        overflow: 'hidden',
        flex: 1
    },
    did: {
        textOverflow: 'ellipsis',
        overflow: 'hidden',
        whiteSpace: 'nowrap'
    },
    variableName: {
        overflowWrap: 'break-word',
        color: 'var(--jp-ui-font-color2)'
    },
    statusIcon: {
        marginTop: '2px',
        fontSize: '9pt'
    },
    availableIcon: {
        extend: 'statusIcon',
        color: 'var(--jp-success-color0)'
    },
    notAvailableIcon: {
        extend: 'statusIcon',
        color: 'var(--jp-error-color1)'
    },
    replicatingIcon: {
        extend: 'statusIcon',
        color: 'var(--jp-rucio-yellow-color)'
    },
    pendingInjectionIcon: {
        extend: 'statusIcon',
        color: 'var(--jp-success-color0)',
        opacity: 0.5
    },
    notResolvedIcon: {
        extend: 'statusIcon',
        color: 'var(--jp-ui-font-color2)'
    },
    actionContainer: {},
    clearButton: {
        alignItems: 'center',
        padding: '4px',
        lineHeight: 0,
        cursor: 'pointer'
    },
    clearIcon: {
        color: 'var(--jp-error-color1)',
        opacity: 0.5,
        fontSize: '16px',
        lineHeight: '24px',
        '&:hover': {
            opacity: 1
        }
    },
    action: {
        fontSize: '9pt',
        color: 'var(--jp-rucio-primary-blue-color)',
        cursor: 'pointer'
    }
});
const _UploadJobListItem = ({ job, onDeleteClick }) => {
    const classes = useStyles();
    const app = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(_const__WEBPACK_IMPORTED_MODULE_2__.JupyterLabAppContext);
    const showLog = () => {
        const widget = new _widgets_UploadLogViewerWidget__WEBPACK_IMPORTED_MODULE_3__.UploadLogViewerWidget(job.id);
        app === null || app === void 0 ? void 0 : app.shell.add(widget, 'main');
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.listItemContainer },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.listItemIconContainer },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(StatusIcon, { status: job.status })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.listItemContent },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.did }, job.did),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.variableName },
                job.path,
                " \u2192 ",
                job.rse),
            job.status === 'FAILED' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.action, onClick: showLog }, "Show Log"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.actionContainer }, job.status !== 'UPLOADING' && !!onDeleteClick && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.clearButton, onClick: onDeleteClick },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.clearIcon} material-icons` }, "clear"))))));
};
const StatusIcon = ({ status }) => {
    const classes = useStyles();
    switch (status) {
        case 'UPLOADING':
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Spinning__WEBPACK_IMPORTED_MODULE_4__.Spinning, { className: `${classes.replicatingIcon} material-icons` }, "hourglass_top"));
        case 'OK':
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.availableIcon} material-icons` }, "check_circle"));
        case 'FAILED':
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.notAvailableIcon} material-icons` }, "cancel"));
        default:
            return react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null);
    }
};
const UploadJobListItem = (0,_utils_Actions__WEBPACK_IMPORTED_MODULE_5__.withRequestAPI)(_UploadJobListItem);


/***/ }),

/***/ "./lib/components/@Uploads/UploadsTab.js":
/*!***********************************************!*\
  !*** ./lib/components/@Uploads/UploadsTab.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UploadsTab: () => (/* binding */ UploadsTab)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _UploadJobListItem__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./UploadJobListItem */ "./lib/components/@Uploads/UploadJobListItem.js");
/* harmony import */ var _HorizontalHeading__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../HorizontalHeading */ "./lib/components/HorizontalHeading.js");
/* harmony import */ var _utils_useInterval__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../utils/useInterval */ "./lib/utils/useInterval.js");
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! pullstate */ "webpack/sharing/consume/default/pullstate/pullstate");
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(pullstate__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _stores_UIStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../stores/UIStore */ "./lib/stores/UIStore.js");
/* harmony import */ var _utils_Actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../utils/Actions */ "./lib/utils/Actions.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020-2021
 */








const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    container: {
        padding: '16px 0 16px 0'
    },
    messageContainer: {
        padding: '16px'
    }
});
const UploadsTab = ({ visible }) => {
    const classes = useStyles();
    const activeInstance = (0,pullstate__WEBPACK_IMPORTED_MODULE_2__.useStoreState)(_stores_UIStore__WEBPACK_IMPORTED_MODULE_3__.UIStore, s => s.activeInstance);
    const [jobs, setJobs] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const loadJobs = () => {
        if (!activeInstance) {
            return;
        }
        _utils_Actions__WEBPACK_IMPORTED_MODULE_4__.actions
            .fetchUploadJobs(activeInstance.name)
            .then(jobs => setJobs(jobs))
            .catch(e => console.log(e));
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (visible) {
            loadJobs();
        }
    }, [activeInstance, visible]);
    (0,_utils_useInterval__WEBPACK_IMPORTED_MODULE_5__["default"])(() => {
        if (visible) {
            loadJobs();
        }
    }, 5000);
    const onDelete = (id) => {
        if (!activeInstance) {
            return;
        }
        _utils_Actions__WEBPACK_IMPORTED_MODULE_4__.actions
            .deleteUploadJob(activeInstance.name, id)
            .then(() => {
            console.log('Job deleted');
            const newJobs = jobs.filter(j => j.id !== id);
            setJobs(newJobs);
        })
            .finally(() => {
            loadJobs();
        });
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        jobs.length > 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.container },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_HorizontalHeading__WEBPACK_IMPORTED_MODULE_6__.HorizontalHeading, { title: "Upload Jobs" }),
                jobs.map(job => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_UploadJobListItem__WEBPACK_IMPORTED_MODULE_7__.UploadJobListItem, { key: job.id, job: job, onDeleteClick: () => onDelete(job.id) })))))),
        jobs.length === 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.messageContainer }, "You do not have upload jobs."))));
};


/***/ }),

/***/ "./lib/components/Button.js":
/*!**********************************!*\
  !*** ./lib/components/Button.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Button: () => (/* binding */ Button)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */


const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    button: {
        background: 'none',
        padding: 0,
        border: '1px solid',
        borderColor: (props) => `${props.outlineColor || 'var(--jp-border-color1)'}`,
        color: (props) => props.color || 'var(--jp-ui-font-color1)',
        outline: 'none',
        cursor: 'pointer',
        borderRadius: '2px',
        '&:hover': {
            backgroundColor: (props) => `${props.hoverBackgroundColor || 'var(--jp-layout-color2)'}`,
            borderColor: (props) => `${props.outlineColor || 'var(--jp-border-color1)'}`,
            color: (props) => `${props.color || props.hoverTextColor || 'var(--jp-ui-font-color1)'}`
        },
        '&:active': {
            backgroundColor: (props) => `${props.hoverBackgroundColor || 'var(--jp-layout-color2)'}`
        },
        '&:disabled': {
            opacity: 0.5,
            cursor: 'inherit',
            '&:hover': {
                background: 'none',
                borderColor: (props) => `${props.outlineColor || 'var(--jp-border-color1)'}`
            },
            '&:active': {
                background: 'none'
            }
        }
    },
    block: {
        width: '100%',
        display: 'block'
    },
    childrenContainer: {
        margin: '8px 16px 8px 16px'
    }
});
const Button = ({ children, block, onClick, className, ...props }) => {
    const classes = useStyles(props);
    const btnClasses = [classes.button, className];
    if (block) {
        btnClasses.push(classes.block);
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: btnClasses.join(' '), onClick: onClick, ...props },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.childrenContainer }, children)));
};


/***/ }),

/***/ "./lib/components/Header.js":
/*!**********************************!*\
  !*** ./lib/components/Header.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Header: () => (/* binding */ Header)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _RucioLogo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./RucioLogo */ "./lib/components/RucioLogo.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */



const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    container: {
        padding: '16px 8px 8px 8px'
    }
});
const Header = props => {
    const classes = useStyles();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.container, ...props },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_RucioLogo__WEBPACK_IMPORTED_MODULE_2__["default"], null)));
};


/***/ }),

/***/ "./lib/components/HorizontalHeading.js":
/*!*********************************************!*\
  !*** ./lib/components/HorizontalHeading.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HorizontalHeading: () => (/* binding */ HorizontalHeading)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */


const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    heading: {
        borderBottom: '1px solid var(--jp-border-color2)',
        margin: 0,
        padding: '24px 16px 8px 16px',
        fontWeight: 'bold',
        textAlign: 'start',
        fontSize: '9pt',
        textTransform: 'uppercase'
    }
});
const HorizontalHeading = ({ title }) => {
    const classes = useStyles();
    return react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.heading }, title);
};


/***/ }),

/***/ "./lib/components/MenuBar.js":
/*!***********************************!*\
  !*** ./lib/components/MenuBar.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MenuBar: () => (/* binding */ MenuBar)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */


const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    tab: {
        borderBottom: '1px solid var(--jp-border-color2)',
        listStyleType: 'none',
        margin: 0,
        padding: '0 8px 0 8px',
        overflow: 'hidden'
    },
    tabItem: {
        float: 'left',
        display: 'block',
        padding: '8px 12px 8px 12px',
        textTransform: 'uppercase',
        borderRadius: '4px 4px 0 0',
        fontSize: '9pt',
        cursor: 'pointer',
        '&:hover': {
            background: 'var(--jp-layout-color2)'
        },
        '&.active': {
            background: 'var(--jp-layout-color2)',
            fontWeight: 'bold'
        },
        '&.disabled': {
            opacity: 0.5,
            cursor: 'inherit',
            '&:hover': {
                background: 'none'
            },
            '&.active': {
                background: 'none'
            }
        }
    },
    tabItemRight: {
        extend: 'tabItem',
        float: 'right'
    }
});
const MenuBar = ({ menus, value, onChange }) => {
    const classes = useStyles();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("ul", { className: classes.tab }, menus.map(menu => {
            const activeClass = menu.value === value ? 'active' : '';
            const disabledClass = menu.disabled ? 'disabled' : '';
            const tabClass = menu.right ? classes.tabItemRight : classes.tabItem;
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", { onClick: !menu.disabled ? () => onChange(menu.value) : undefined, key: menu.value, className: `${tabClass} ${activeClass} ${disabledClass}` }, menu.title));
        }))));
};


/***/ }),

/***/ "./lib/components/RucioLogo.js":
/*!*************************************!*\
  !*** ./lib/components/RucioLogo.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

/* eslint-disable max-len */
const logoSvg = `
<svg width="100px" viewBox="0 0 1779 453" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" xmlns:serif="http://www.serif.com/" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2;">
    <g transform="matrix(1,0,0,1,-3188,-9151.54)">
        <g transform="matrix(4.16667,0,0,4.16667,4082.17,9382.56)">
            <g transform="matrix(1,0,0,1,-297.64,-209.765)">
                <path d="M237.05,194.69C237.05,180.103 226.987,172.807 206.86,172.8L182.59,172.8L182.59,246.88L202.59,246.88L202.59,219.88L207.66,219.88L223.37,246.88L246.06,246.88L224.49,214.6C232.87,209.913 237.057,203.277 237.05,194.69ZM206.35,204.87L202.6,204.87L202.6,188L206.6,188C213.46,188 216.89,190.55 216.89,195.65C216.857,201.797 213.343,204.87 206.35,204.87Z" style="fill:var(--jp-ui-font-color1);fill-rule:nonzero;"/>
                <path d="M295.78,216.17C295.78,221.503 294.857,225.347 293.01,227.7C291.163,230.053 288.2,231.227 284.12,231.22C280.307,231.22 277.42,230.037 275.46,227.67C273.5,225.303 272.52,221.503 272.52,216.27L272.52,172.8L252.41,172.8L252.41,217.8C252.41,227.487 255.12,234.917 260.54,240.09C265.96,245.263 273.72,247.847 283.82,247.84C294.16,247.84 302.073,245.173 307.56,239.84C313.047,234.507 315.79,227 315.79,217.32L315.79,172.8L295.79,172.8L295.78,216.17Z" style="fill:var(--jp-ui-font-color1);fill-rule:nonzero;"/>
                <path d="M364.33,188.15C367.318,188.127 370.29,188.572 373.14,189.47C375.943,190.374 378.685,191.456 381.35,192.71L387.48,177C380.307,173.543 372.442,171.758 364.48,171.78C357.8,171.615 351.196,173.234 345.35,176.47C339.944,179.581 335.6,184.252 332.89,189.87C329.922,196.157 328.456,203.049 328.61,210C328.61,222.26 331.59,231.633 337.55,238.12C343.51,244.607 352.08,247.85 363.26,247.85C370.47,247.972 377.625,246.575 384.26,243.75L384.26,226.86C381.23,228.122 378.136,229.223 374.99,230.16C371.896,231.071 368.686,231.529 365.46,231.52C354.62,231.52 349.2,224.393 349.2,210.14C349.2,203.293 350.533,197.917 353.2,194.01C355.621,190.243 359.854,188.014 364.33,188.15Z" style="fill:var(--jp-ui-font-color1);fill-rule:nonzero;"/>
                <rect x="398.68" y="172.8" width="20.11" height="74.07" style="fill:var(--jp-ui-font-color1);"/>
                <path d="M495,181.31C488.92,174.863 479.983,171.64 468.19,171.64C456.397,171.64 447.437,174.89 441.31,181.39C435.15,187.89 432.07,197.307 432.07,209.64C432.07,222.1 435.17,231.59 441.37,238.11C447.57,244.63 456.477,247.89 468.09,247.89C479.883,247.89 488.833,244.647 494.94,238.16C501.047,231.673 504.107,222.2 504.12,209.74C504.12,197.247 501.08,187.77 495,181.31ZM479.37,226C476.923,229.48 473.163,231.22 468.09,231.22C458.13,231.22 453.15,224.06 453.15,209.74C453.15,195.28 458.15,188.05 468.15,188.05C473.083,188.05 476.79,189.817 479.27,193.35C481.75,196.883 482.993,202.347 483,209.74C483,217.1 481.79,222.52 479.37,226Z" style="fill:var(--jp-ui-font-color1);fill-rule:nonzero;"/>
                <path d="M164.12,233.55L164.12,242.81C164.115,243.788 163.308,244.59 162.33,244.59L96.24,244.59C95.264,244.59 94.46,243.786 94.46,242.81L91.16,242.81C91.165,245.595 93.455,247.885 96.24,247.89L162.33,247.89C165.115,247.885 167.405,245.595 167.41,242.81L167.41,230.59C166.513,231.779 165.396,232.784 164.12,233.55Z" style="fill:var(--jp-ui-font-color1);fill-rule:nonzero;"/>
                <path d="M164.12,176.72L164.12,213.52C165.401,214.298 166.518,215.316 167.41,216.52L167.41,176.72C167.405,173.935 165.115,171.645 162.33,171.64L125.18,171.64L125.18,174.93L162.33,174.93C163.312,174.93 164.12,175.738 164.12,176.72Z" style="fill:var(--jp-ui-font-color1);fill-rule:nonzero;"/>
                <path d="M162.92,215.14L154.52,210.3L145,204.79C139.786,201.786 133.026,203.589 130,208.79L111.2,241.3L136.65,241.3L146,225.13L149,226.85C150.396,230.665 154.047,233.217 158.109,233.217C163.431,233.217 167.809,228.838 167.809,223.517C167.809,220.072 165.975,216.877 163,215.14L162.92,215.14ZM143.56,210.31C144.272,209.069 145.598,208.301 147.029,208.301C149.223,208.301 151.029,210.107 151.029,212.301C151.029,214.496 149.223,216.301 147.029,216.301C146.323,216.301 145.63,216.114 145.02,215.76C143.129,214.662 142.472,212.206 143.56,210.31ZM165.93,228.08C164.312,230.883 161.312,232.615 158.075,232.615C154.269,232.615 150.849,230.218 149.55,226.64L149.47,226.43L149.27,226.31L146.27,224.59L149.01,219.85C149.12,219.66 149.23,219.46 149.32,219.27L154.19,210.84L162.59,215.68C166.903,218.169 168.41,223.762 165.93,228.08Z" style="fill:var(--jp-ui-font-color1);fill-rule:nonzero;"/>
                <circle cx="164.08" cy="223.16" r="1.7" style="fill:var(--jp-ui-font-color1);"/>
                <path d="M110.09,238.4L107.4,236.85L108.96,234.15L111.65,235.71L110.09,238.4ZM113.2,233L110.51,231.45L112.07,228.76L114.76,230.31L113.2,233ZM116.31,227.62L113.62,226.06L115.18,223.37L117.87,224.93L116.31,227.62ZM119.42,222.23L116.73,220.68L118.28,217.99L120.98,219.54L119.42,222.23ZM122.53,216.85L119.84,215.29L121.39,212.6L124.09,214.16L122.53,216.85ZM125.64,211.46L123,209.92L124.55,207.23L127.25,208.78L125.64,211.46ZM128.74,206.29L126.25,204.43C126.93,203.509 127.708,202.664 128.57,201.91L130.62,204.24C129.922,204.858 129.291,205.548 128.74,206.3L128.74,206.29ZM146.21,202.7C145.404,202.235 144.553,201.853 143.67,201.56L144.67,198.61C145.757,198.963 146.804,199.432 147.79,200.01L146.21,202.7ZM132.89,202.63L131.36,199.92C132.359,199.363 133.411,198.907 134.5,198.56L135.44,201.56C134.556,201.835 133.702,202.197 132.89,202.64L132.89,202.63ZM141,201C140.076,200.9 139.144,200.9 138.22,201L137.91,197.9C139.047,197.78 140.193,197.78 141.33,197.9L141,201Z" style="fill:var(--jp-ui-font-color1);fill-rule:nonzero;"/>
                <path d="M111.56,181.07C111.454,180.947 111.396,180.79 111.396,180.627C111.396,180.254 111.703,179.947 112.076,179.947C112.135,179.947 112.193,179.955 112.25,179.97C120.411,181.977 126.373,189.084 126.93,197.47C126.931,197.484 126.931,197.499 126.931,197.513C126.931,197.887 126.624,198.193 126.251,198.193C126.05,198.193 125.859,198.104 125.73,197.95L111.56,181.07Z" style="fill:var(--jp-ui-font-color1);fill-rule:nonzero;"/>
                <path d="M96.6,189.58C96.469,189.503 96.319,189.463 96.167,189.463C95.695,189.463 95.307,189.851 95.307,190.323C95.307,190.442 95.332,190.561 95.38,190.67C99.674,200.429 109.871,206.314 120.47,205.15C120.902,205.1 121.232,204.73 121.232,204.296C121.232,203.988 121.067,203.703 120.8,203.55L96.6,189.58Z" style="fill:var(--jp-ui-font-color1);fill-rule:nonzero;"/>
                <circle cx="149.3" cy="212.22" r="1.7" style="fill:var(--jp-ui-font-color1);"/>
                <path d="M166,228.18C162.98,228.18 159.967,227.899 157,227.34L156.7,228.91C159.388,229.422 162.114,229.71 164.85,229.77C165.296,229.295 165.691,228.776 166.03,228.22L166,228.18Z" style="fill:var(--jp-ui-font-color1);fill-rule:nonzero;"/>
            </g>
        </g>
    </g>
</svg>
`;
/* eslint-enable max-len */
const RucioLogo = () => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { dangerouslySetInnerHTML: { __html: logoSvg } }));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RucioLogo);


/***/ }),

/***/ "./lib/components/Spinning.js":
/*!************************************!*\
  !*** ./lib/components/Spinning.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Spinning: () => (/* binding */ Spinning)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */


const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    '@keyframes rotation': {
        from: {
            transform: 'rotate(0deg)'
        },
        to: {
            transform: 'rotate(359deg)'
        }
    },
    rotate: {
        animation: '$rotation 1s infinite linear',
        animationName: '$rotation'
    }
});
const Spinning = ({ children, className, ...props }) => {
    const classes = useStyles();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: `${className} ${classes.rotate}`, ...props }, children));
};


/***/ }),

/***/ "./lib/components/TextField.js":
/*!*************************************!*\
  !*** ./lib/components/TextField.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TextField: () => (/* binding */ TextField)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */


const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    control: {
        display: 'flex',
        flexDirection: 'row',
        border: (props) => `1px solid ${props.outlineColor || 'var(--jp-border-color1)'}`,
        alignItems: 'stretch'
    },
    input: {
        flex: 1,
        background: 'none',
        border: 'none',
        outline: 'none',
        padding: '8px',
        minWidth: 0,
        color: (props) => props.color || 'var(--jp-ui-font-color1)'
    },
    block: {
        width: '100%'
    }
});
const _TextField = (props, ref) => {
    const { block, before, after, outlineColor, className, containerStyle, ...carriedProps } = props;
    const classes = useStyles({ outlineColor });
    const inputClasses = [classes.input];
    if (block) {
        inputClasses.push(classes.block);
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.control, style: containerStyle },
        before,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { ref: ref, type: "text", className: inputClasses.join(' ') + ' ' + className || '', ...carriedProps }),
        after));
};
const TextField = react__WEBPACK_IMPORTED_MODULE_0___default().forwardRef(_TextField);


/***/ }),

/***/ "./lib/const.js":
/*!**********************!*\
  !*** ./lib/const.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   COMM_NAME_FRONTEND: () => (/* binding */ COMM_NAME_FRONTEND),
/* harmony export */   COMM_NAME_KERNEL: () => (/* binding */ COMM_NAME_KERNEL),
/* harmony export */   CommandIDs: () => (/* binding */ CommandIDs),
/* harmony export */   EXTENSION_ID: () => (/* binding */ EXTENSION_ID),
/* harmony export */   JupyterLabAppContext: () => (/* binding */ JupyterLabAppContext),
/* harmony export */   METADATA_ATTACHMENTS_KEY: () => (/* binding */ METADATA_ATTACHMENTS_KEY),
/* harmony export */   searchByOptions: () => (/* binding */ searchByOptions)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const EXTENSION_ID = 'rucio-jupyterlab';
const METADATA_ATTACHMENTS_KEY = 'rucio_attachments';
const COMM_NAME_KERNEL = `${EXTENSION_ID}:kernel`;
const COMM_NAME_FRONTEND = `${EXTENSION_ID}:frontend`;
const searchByOptions = [
    { title: 'Datasets or Containers', value: 'datasets' },
    { title: 'Files', value: 'files' }
];
var CommandIDs;
(function (CommandIDs) {
    CommandIDs.UploadFile = `${EXTENSION_ID}:upload-file`;
    CommandIDs.OpenUploadLog = `${EXTENSION_ID}:open-upload-log`;
})(CommandIDs || (CommandIDs = {}));
const JupyterLabAppContext = react__WEBPACK_IMPORTED_MODULE_0___default().createContext(undefined);


/***/ }),

/***/ "./lib/icons/RucioIcon.js":
/*!********************************!*\
  !*** ./lib/icons/RucioIcon.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   rucioIcon: () => (/* binding */ rucioIcon)
/* harmony export */ });
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__);
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */

/* eslint-disable max-len */
const rucioSvg = `
<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" version="1.1" viewBox="0 0 2280 2280">
   <g transform="matrix(1,0,0,1,-1702,-5402)">
        <g transform="matrix(1,0,0,1,-8,-900)">
            <rect x="1710" y="6302" width="2280" height="2280" style="fill:rgb(235,235,235);fill-opacity:0;"/>
            <g transform="matrix(10.352,0,0,10.352,2850,7442)">
                <g transform="matrix(1,0,0,1,-297.64,-209.765)">
                    <path d="M384.27,269.23L384.27,292.37C384.27,294.822 382.252,296.84 379.8,296.84L214.58,296.84C212.132,296.835 210.12,294.818 210.12,292.37L201.88,292.37C201.885,299.337 207.613,305.069 214.58,305.08L379.8,305.08C386.77,305.075 392.505,299.34 392.51,292.37L392.51,261.84C390.255,264.802 387.459,267.309 384.27,269.23Z" style="fill:var(--jp-ui-font-color1);fill-rule:nonzero;"/>
                    <path d="M384.27,127.15L384.27,219.15C387.464,221.068 390.261,223.58 392.51,226.55L392.51,127.15C392.499,120.183 386.767,114.455 379.8,114.45L286.94,114.45L286.94,122.69L379.8,122.69C382.248,122.69 384.265,124.702 384.27,127.15Z" style="fill:var(--jp-ui-font-color1);fill-rule:nonzero;"/>
                    <path d="M381.28,223.21L360.28,211.1L336.42,197.32C323.34,189.796 306.386,194.353 298.84,207.42L252,288.61L315.6,288.61L338.93,248.18L346.38,252.49C349.856,262.045 358.992,268.442 369.159,268.442C382.457,268.442 393.399,257.5 393.399,244.202C393.399,235.553 388.77,227.535 381.28,223.21ZM332.87,211.14C334.65,208.035 337.966,206.114 341.545,206.114C347.031,206.114 351.545,210.628 351.545,216.114C351.545,221.6 347.031,226.114 341.545,226.114C339.78,226.114 338.046,225.647 336.52,224.76C331.796,222.014 330.152,215.88 332.87,211.14ZM388.8,255.55C384.76,262.583 377.244,266.933 369.134,266.933C359.599,266.933 351.036,260.919 347.8,251.95L347.61,251.42L347.12,251.14L339.67,246.84L346.56,235C346.84,234.52 347.09,234 347.34,233.54L359.51,212.46L380.51,224.58C391.256,230.819 394.992,244.777 388.8,255.55Z" style="fill:var(--jp-ui-font-color1);fill-rule:nonzero;"/>
                    <circle cx="384.17" cy="243.25" r="4.25" style="fill:var(--jp-ui-font-color1);"/>
                    <path d="M249.21,281.35L242.48,277.47L246.37,270.74L253.1,274.62L249.21,281.35ZM257,267.89L250.25,264L254.14,257.27L260.87,261.16L257,267.89ZM264.77,254.43L258,250.54L261.88,243.81L268.62,247.7L264.77,254.43ZM272.53,241L265.8,237.12L269.69,230.39L276.42,234.27L272.53,241ZM280.31,227.54L273.57,223.65L277.46,216.92L284.19,220.81L280.31,227.54ZM288.08,214L281.35,210.11L285.23,203.38L292,207.3L288.08,214ZM295.82,201.05L289.59,196.4C291.303,194.107 293.25,191.999 295.4,190.11L300.53,195.94C298.788,197.491 297.21,199.217 295.82,201.09L295.82,201.05ZM339.49,192.05C337.477,190.887 335.349,189.935 333.14,189.21L335.56,181.82C338.281,182.713 340.901,183.886 343.38,185.32L339.49,192.05ZM306.2,192L302.39,185.23C304.881,183.824 307.512,182.681 310.24,181.82L312.58,189.24C310.365,189.942 308.228,190.867 306.2,192ZM326.35,187.86C324.023,187.617 321.677,187.617 319.35,187.86L318.57,180.13C321.419,179.835 324.291,179.835 327.14,180.13L326.35,187.86Z" style="fill:var(--jp-ui-font-color1);fill-rule:nonzero;"/>
                    <path d="M252.89,138C252.637,137.695 252.498,137.311 252.498,136.914C252.498,135.982 253.265,135.214 254.198,135.214C254.33,135.214 254.462,135.23 254.59,135.26C274.999,140.263 289.913,158.032 291.3,179C291.304,179.046 291.306,179.093 291.306,179.139C291.306,180.067 290.543,180.829 289.616,180.829C289.105,180.829 288.621,180.598 288.3,180.2L252.89,138Z" style="fill:var(--jp-ui-font-color1);fill-rule:nonzero;"/>
                    <path d="M215.48,159.31C215.167,159.141 214.816,159.053 214.46,159.053C213.281,159.053 212.31,160.023 212.31,161.203C212.31,161.49 212.368,161.775 212.48,162.04C223.217,186.426 248.693,201.134 275.18,198.24C276.269,198.125 277.105,197.197 277.105,196.102C277.105,195.335 276.694,194.624 276.03,194.24L215.48,159.31Z" style="fill:var(--jp-ui-font-color1);fill-rule:nonzero;"/>
                    <circle cx="347.23" cy="215.91" r="4.25" style="fill:var(--jp-ui-font-color1);"/>
                    <path d="M389,255.82C381.433,255.82 373.883,255.107 366.45,253.69L365.7,257.62C372.412,258.902 379.219,259.624 386.05,259.78C387.188,258.6 388.194,257.299 389.05,255.9L389,255.82Z" style="fill:var(--jp-ui-font-color1);fill-rule:nonzero;"/>
                </g>
            </g>
        </g>
    </g>
</svg>
`;
/* eslint-enable max-len */
const rucioIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'rucio-jupyterlab:rucio',
    svgstr: rucioSvg
});


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _const__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./const */ "./lib/const.js");
/* harmony import */ var _widgets_SidebarPanel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./widgets/SidebarPanel */ "./lib/widgets/SidebarPanel.js");
/* harmony import */ var _utils_Actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./utils/Actions */ "./lib/utils/Actions.js");
/* harmony import */ var _utils_NotebookListener__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./utils/NotebookListener */ "./lib/utils/NotebookListener.js");
/* harmony import */ var _utils_ActiveNotebookListener__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./utils/ActiveNotebookListener */ "./lib/utils/ActiveNotebookListener.js");
/* harmony import */ var _utils_NotebookPollingListener__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./utils/NotebookPollingListener */ "./lib/utils/NotebookPollingListener.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */


// import { fileUploadIcon } from '@jupyterlab/ui-components';

// import { toArray } from '@lumino/algorithm';
// import { CommandIDs } from './const';






/**
 * Initialization data for the rucio-jupyterlab extension.
 */
const extension = {
    id: _const__WEBPACK_IMPORTED_MODULE_3__.EXTENSION_ID,
    autoStart: true,
    requires: [_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__.ILabShell, _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__.INotebookTracker, _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2__.IFileBrowserFactory],
    activate: async (app, labShell, notebookTracker, fileBrowserFactory) => {
        try {
            const instanceConfig = await _utils_Actions__WEBPACK_IMPORTED_MODULE_4__.actions.fetchInstancesConfig();
            activateSidebarPanel(app, labShell, instanceConfig);
            activateNotebookListener(app, labShell, notebookTracker);
            //       activateRucioUploadWidget(app, fileBrowserFactory);
        }
        catch (e) {
            console.log(e);
        }
    }
};
function activateSidebarPanel(app, labShell, instanceConfig) {
    const sidebarPanel = new _widgets_SidebarPanel__WEBPACK_IMPORTED_MODULE_5__.SidebarPanel({ app, instanceConfig });
    sidebarPanel.id = _const__WEBPACK_IMPORTED_MODULE_3__.EXTENSION_ID + ':panel';
    labShell.add(sidebarPanel, 'left', { rank: 900 });
    labShell.activateById(sidebarPanel.id);
}
function activateNotebookListener(app, labShell, notebookTracker) {
    const notebookListener = new _utils_NotebookListener__WEBPACK_IMPORTED_MODULE_6__.NotebookListener({
        labShell,
        notebookTracker,
        sessionManager: app.serviceManager.sessions
    });
    new _utils_ActiveNotebookListener__WEBPACK_IMPORTED_MODULE_7__.ActiveNotebookListener({
        labShell,
        notebookTracker,
        sessionManager: app.serviceManager.sessions,
        notebookListener: notebookListener
    });
    new _utils_NotebookPollingListener__WEBPACK_IMPORTED_MODULE_8__.NotebookPollingListener(notebookListener);
}
/*function activateRucioUploadWidget(
  app: JupyterFrontEnd,
  fileBrowserFactory: IFileBrowserFactory
) {
  app.commands.addCommand(CommandIDs.UploadFile, {
    icon: fileUploadIcon,
    label: 'Upload File(s) to Rucio',
    execute: async () => {
      const widget = fileBrowserFactory.tracker.currentWidget;

      if (widget) {
        const selection = toArray(widget.selectedItems()).filter(
          s => s.type !== 'directory'
        );
        if (selection.length === 0) {
          return;
        }
        uploadFile(selection);
      }
    }
  });

  app.contextMenu.addItem({
    command: CommandIDs.UploadFile,
    selector: '.jp-DirListing-item[data-isdir="false"]',
    rank: 10
  });
}*/
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (extension);


/***/ }),

/***/ "./lib/stores/ExtensionStore.js":
/*!**************************************!*\
  !*** ./lib/stores/ExtensionStore.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ExtensionStore: () => (/* binding */ ExtensionStore),
/* harmony export */   initialState: () => (/* binding */ initialState)
/* harmony export */ });
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! pullstate */ "webpack/sharing/consume/default/pullstate/pullstate");
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(pullstate__WEBPACK_IMPORTED_MODULE_0__);
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */

const initialState = {};
const ExtensionStore = new pullstate__WEBPACK_IMPORTED_MODULE_0__.Store(initialState);


/***/ }),

/***/ "./lib/stores/UIStore.js":
/*!*******************************!*\
  !*** ./lib/stores/UIStore.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UIStore: () => (/* binding */ UIStore),
/* harmony export */   initialState: () => (/* binding */ initialState),
/* harmony export */   resetRucioCaches: () => (/* binding */ resetRucioCaches)
/* harmony export */ });
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! pullstate */ "webpack/sharing/consume/default/pullstate/pullstate");
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(pullstate__WEBPACK_IMPORTED_MODULE_0__);
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */

const initialState = {
    fileDetails: {},
    collectionDetails: {}
};
const UIStore = new pullstate__WEBPACK_IMPORTED_MODULE_0__.Store(initialState);
const resetRucioCaches = () => {
    UIStore.update(s => {
        s.fileDetails = {};
        s.collectionDetails = {};
    });
};


/***/ }),

/***/ "./lib/utils/Actions.js":
/*!******************************!*\
  !*** ./lib/utils/Actions.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Actions: () => (/* binding */ Actions),
/* harmony export */   actions: () => (/* binding */ actions),
/* harmony export */   withRequestAPI: () => (/* binding */ withRequestAPI)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! querystring */ "webpack/sharing/consume/default/querystring/querystring");
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(querystring__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ApiRequest__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ApiRequest */ "./lib/utils/ApiRequest.js");
/* harmony import */ var _stores_UIStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../stores/UIStore */ "./lib/stores/UIStore.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 * - Giovanni Guerrieri, <giovanni.guerrieri@cern.ch>, 2025
 */




class Actions {
    async fetchInstancesConfig() {
        return (0,_ApiRequest__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('instances');
    }
    async postActiveInstance(instanceName, authType) {
        const init = {
            method: 'PUT',
            body: JSON.stringify({
                instance: instanceName,
                auth: authType
            })
        };
        return (0,_ApiRequest__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('instances', init);
    }
    async fetchAuthConfig(namespace, type) {
        const query = { namespace, type };
        const encodedQuery = querystring__WEBPACK_IMPORTED_MODULE_1___default().encode(query);
        const response = await (0,_ApiRequest__WEBPACK_IMPORTED_MODULE_2__.requestAPI)(`auth?${encodedQuery}`);
        return response;
    }
    async putAuthConfig(namespace, type, params) {
        const init = {
            method: 'PUT',
            body: JSON.stringify({
                namespace,
                type,
                params
            })
        };
        return (0,_ApiRequest__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('auth', init);
    }
    async searchDID(namespace, did, type, filters) {
        const query = { namespace, did, type, filters };
        return (0,_ApiRequest__WEBPACK_IMPORTED_MODULE_2__.requestAPI)(`did-search?${querystring__WEBPACK_IMPORTED_MODULE_1___default().encode(query)}`);
    }
    async fetchScopes(namespace) {
        const query = { namespace };
        return (0,_ApiRequest__WEBPACK_IMPORTED_MODULE_2__.requestAPI)(`list-scopes?${querystring__WEBPACK_IMPORTED_MODULE_1___default().encode(query)}`);
    }
    async fetchRSEs(namespace, expression) {
        const query = { namespace, expression };
        return (0,_ApiRequest__WEBPACK_IMPORTED_MODULE_2__.requestAPI)(`list-rses?${querystring__WEBPACK_IMPORTED_MODULE_1___default().encode(query)}`);
    }
    async fetchAttachedFileDIDs(namespace, did) {
        const query = { namespace, did };
        return (0,_ApiRequest__WEBPACK_IMPORTED_MODULE_2__.requestAPI)(`files?${querystring__WEBPACK_IMPORTED_MODULE_1___default().encode(query)}`);
    }
    async fetchDIDDetails(namespace, did, poll = false, force = false) {
        const query = {
            namespace,
            did,
            poll: poll ? 1 : undefined,
            force: force ? 1 : undefined
        };
        return (0,_ApiRequest__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('did?' + querystring__WEBPACK_IMPORTED_MODULE_1___default().encode(query));
    }
    async getFileDIDDetails(namespace, did, poll = false, force = false) {
        const fileDetails = _stores_UIStore__WEBPACK_IMPORTED_MODULE_3__.UIStore.getRawState().fileDetails[did];
        if (!poll && !force && !!fileDetails) {
            return fileDetails;
        }
        const didDetails = await this.fetchDIDDetails(namespace, did, poll, force);
        const didMap = didDetails.reduce((acc, curr) => {
            acc[curr.did] = curr;
            return acc;
        }, {});
        _stores_UIStore__WEBPACK_IMPORTED_MODULE_3__.UIStore.update(s => {
            s.fileDetails = { ...s.fileDetails, ...didMap };
        });
        return didDetails[0];
    }
    async getCollectionDIDDetails(namespace, did, poll = false, force = false) {
        const collectionDetails = _stores_UIStore__WEBPACK_IMPORTED_MODULE_3__.UIStore.getRawState().collectionDetails[did];
        if (!poll && !force && !!collectionDetails) {
            return collectionDetails;
        }
        const didDetails = await this.fetchDIDDetails(namespace, did, poll, force);
        _stores_UIStore__WEBPACK_IMPORTED_MODULE_3__.UIStore.update(s => {
            s.collectionDetails[did] = didDetails;
        });
        return didDetails;
    }
    async makeFileAvailable(namespace, did) {
        const fileDetails = _stores_UIStore__WEBPACK_IMPORTED_MODULE_3__.UIStore.getRawState().fileDetails[did];
        _stores_UIStore__WEBPACK_IMPORTED_MODULE_3__.UIStore.update(s => {
            s.fileDetails[did] = { ...fileDetails, status: 'REPLICATING' };
        });
        const init = {
            method: 'POST',
            body: JSON.stringify({ did })
        };
        return (0,_ApiRequest__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('did/make-available?namespace=' + encodeURIComponent(namespace), init);
    }
    async makeCollectionAvailable(namespace, did) {
        const collectionAttachedFiles = _stores_UIStore__WEBPACK_IMPORTED_MODULE_3__.UIStore.getRawState().collectionDetails[did];
        const updatedCollectionAttachedFiles = collectionAttachedFiles.map(f => ({
            ...f,
            status: f.status === 'OK' ? 'OK' : 'REPLICATING'
        }));
        _stores_UIStore__WEBPACK_IMPORTED_MODULE_3__.UIStore.update(s => {
            s.collectionDetails[did] = updatedCollectionAttachedFiles;
        });
        const init = {
            method: 'POST',
            body: JSON.stringify({ did })
        };
        return (0,_ApiRequest__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('did/make-available?namespace=' + encodeURIComponent(namespace), init);
    }
    async listDirectory(path) {
        return (0,_ApiRequest__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('file-browser?path=' + encodeURIComponent(path));
    }
    async purgeCache() {
        const init = {
            method: 'POST'
        };
        return (0,_ApiRequest__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('purge-cache', init);
    }
    async uploadFile(namespace, params) {
        const { paths, rse, fileScope, datasetName, addToDataset, datasetScope, lifetime } = params;
        const init = {
            method: 'POST',
            body: JSON.stringify({
                file_paths: paths,
                rse,
                scope: fileScope,
                add_to_dataset: !!addToDataset,
                dataset_scope: datasetScope,
                dataset_name: datasetName,
                lifetime
            })
        };
        return (0,_ApiRequest__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('upload?namespace=' + encodeURIComponent(namespace), init);
    }
    async fetchUploadJobs(namespace) {
        const query = { namespace };
        return (0,_ApiRequest__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('upload/jobs?' + querystring__WEBPACK_IMPORTED_MODULE_1___default().encode(query));
    }
    async fetchUploadJobLog(namespace, id) {
        const query = { namespace, id };
        return (0,_ApiRequest__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('upload/jobs/log?' + querystring__WEBPACK_IMPORTED_MODULE_1___default().encode(query));
    }
    async deleteUploadJob(namespace, id) {
        const query = { namespace, id };
        const init = {
            method: 'DELETE'
        };
        return (0,_ApiRequest__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('upload/jobs/details?' + querystring__WEBPACK_IMPORTED_MODULE_1___default().encode(query), init);
    }
}
const actions = new Actions();
//eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
function withRequestAPI(Component) {
    return class WithRequestAPI extends (react__WEBPACK_IMPORTED_MODULE_0___default().Component) {
        //eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
        render() {
            const { ...props } = this.props;
            return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Component, { ...props, actions: actions });
        }
    };
}


/***/ }),

/***/ "./lib/utils/ActiveNotebookListener.js":
/*!*********************************************!*\
  !*** ./lib/utils/ActiveNotebookListener.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ActiveNotebookListener: () => (/* binding */ ActiveNotebookListener)
/* harmony export */ });
/* harmony import */ var _stores_ExtensionStore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../stores/ExtensionStore */ "./lib/stores/ExtensionStore.js");
/* harmony import */ var _const__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../const */ "./lib/const.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */


class ActiveNotebookListener {
    constructor(options) {
        this.options = options;
        this.setup();
    }
    setup() {
        const { labShell } = this.options;
        _stores_ExtensionStore__WEBPACK_IMPORTED_MODULE_0__.ExtensionStore.subscribe(s => s.activeNotebookAttachment, (attachments, state) => {
            if (attachments) {
                this.onNotebookAttachmentChanged(attachments, state);
            }
        });
        labShell.currentChanged.connect(this.onCurrentTabChanged, this);
    }
    onNotebookAttachmentChanged(attachments, state) {
        var _a;
        const { activeNotebookPanel } = state;
        if (!attachments || !activeNotebookPanel) {
            return;
        }
        this.setJupyterNotebookFileRucioMetadata(attachments, state);
        if ((_a = activeNotebookPanel.sessionContext.session) === null || _a === void 0 ? void 0 : _a.kernel) {
            activeNotebookPanel.sessionContext.ready.then(() => {
                const { notebookListener } = this.options;
                notebookListener.injectUninjected(activeNotebookPanel);
            });
        }
    }
    setJupyterNotebookFileRucioMetadata(attachments, state) {
        var _a;
        const metadata = (_a = state.activeNotebookPanel) === null || _a === void 0 ? void 0 : _a.model;
        if (!metadata) {
            return;
        }
        const current = metadata.getMetadata(_const__WEBPACK_IMPORTED_MODULE_1__.METADATA_ATTACHMENTS_KEY);
        const rucioDidAttachments = attachments;
        if (current !== rucioDidAttachments) {
            if (rucioDidAttachments.length === 0) {
                if (current) {
                    metadata.deleteMetadata(_const__WEBPACK_IMPORTED_MODULE_1__.METADATA_ATTACHMENTS_KEY);
                }
            }
            else {
                metadata.setMetadata(_const__WEBPACK_IMPORTED_MODULE_1__.METADATA_ATTACHMENTS_KEY, rucioDidAttachments);
            }
        }
    }
    onCurrentTabChanged() {
        if (!this.isCurrentTabANotebook()) {
            this.setActiveNotebook(undefined);
            this.setActiveNotebookAttachments(undefined);
            return;
        }
        const { notebookTracker } = this.options;
        const nbWidget = notebookTracker.currentWidget;
        if (!nbWidget) {
            return;
        }
        nbWidget.revealed.then(() => {
            var _a;
            this.setActiveNotebook(nbWidget);
            const rucioDidAttachments = (_a = nbWidget.model) === null || _a === void 0 ? void 0 : _a.getMetadata(_const__WEBPACK_IMPORTED_MODULE_1__.METADATA_ATTACHMENTS_KEY);
            if (!rucioDidAttachments) {
                this.setActiveNotebookAttachments([]);
                return;
            }
            const attachedDIDs = rucioDidAttachments;
            this.setActiveNotebookAttachments(attachedDIDs);
        });
    }
    isCurrentTabANotebook() {
        const { labShell, notebookTracker } = this.options;
        const widget = labShell.currentWidget;
        const nbWidget = notebookTracker.currentWidget;
        return !!widget && widget === nbWidget;
    }
    setActiveNotebook(activeNotebook) {
        _stores_ExtensionStore__WEBPACK_IMPORTED_MODULE_0__.ExtensionStore.update(s => {
            s.activeNotebookPanel = activeNotebook;
        });
    }
    setActiveNotebookAttachments(attachments) {
        _stores_ExtensionStore__WEBPACK_IMPORTED_MODULE_0__.ExtensionStore.update(s => {
            s.activeNotebookAttachment = attachments;
        });
    }
}


/***/ }),

/***/ "./lib/utils/ApiRequest.js":
/*!*********************************!*\
  !*** ./lib/utils/ApiRequest.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   requestAPI: () => (/* binding */ requestAPI)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var camelcase_keys_deep__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! camelcase-keys-deep */ "webpack/sharing/consume/default/camelcase-keys-deep/camelcase-keys-deep");
/* harmony import */ var camelcase_keys_deep__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(camelcase_keys_deep__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _const__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../const */ "./lib/const.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 * - Enrique Garcia, (CERN), 2024
 */




/**
 * Call the API extension
 *
 * @param endPoint API REST end point for the extension
 * @param init Initial values for the request
 * @returns The response body interpreted as JSON
 */
async function requestAPI(endPoint = '', init = {}, convertSnakeCase = true) {
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const [path, queryString] = endPoint.split('?');
    const base = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, _const__WEBPACK_IMPORTED_MODULE_3__.EXTENSION_ID, path);
    const requestUrl = queryString ? `${base}?${queryString}` : base;
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(requestUrl, init, settings);
    }
    catch (error) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(error);
    }
    const data = await response.json();
    if (!response.ok) {
        const error = new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response, data.message);
        error.exception_class = data.exception_class;
        error.exception_message = data.exception_message;
        error.error = data.error; // Optional
        throw error;
    }
    return convertSnakeCase ? camelcase_keys_deep__WEBPACK_IMPORTED_MODULE_2___default()(data) : data;
}


/***/ }),

/***/ "./lib/utils/DIDPollingManager.js":
/*!****************************************!*\
  !*** ./lib/utils/DIDPollingManager.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PollingRequesterRef: () => (/* binding */ PollingRequesterRef),
/* harmony export */   didPollingManager: () => (/* binding */ didPollingManager),
/* harmony export */   withPollingManager: () => (/* binding */ withPollingManager)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _stores_UIStore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../stores/UIStore */ "./lib/stores/UIStore.js");
/* harmony import */ var _Actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Actions */ "./lib/utils/Actions.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 * - Giovanni Guerrieri, <giovanni.guerrieri@cern.ch>, 2025
 */



const isBusyStatus = (status) => status === 'REPLICATING' || status === 'FETCHING';
class PollingRequesterRef {
}
class DIDPollingManager {
    constructor() {
        this.pollingRequesterMap = {};
        setInterval(() => {
            this.poll();
        }, 10000);
    }
    requestPolling(did, type, ref, fetchNow = true) {
        if (!this.pollingRequesterMap[did]) {
            this.pollingRequesterMap[did] = { type, refs: [] };
        }
        const requesterRef = ref || new PollingRequesterRef();
        this.pollingRequesterMap[did].refs.push(requesterRef);
        if (fetchNow) {
            this.fetchDid(did);
        }
        return () => {
            this.disablePolling(did, requesterRef);
        };
    }
    disablePolling(did, ref) {
        if (this.pollingRequesterMap[did]) {
            this.pollingRequesterMap[did].refs = this.pollingRequesterMap[did].refs.filter(r => r !== ref);
        }
    }
    poll() {
        const dids = Object.keys(this.pollingRequesterMap).filter(did => {
            return (this.pollingRequesterMap[did] &&
                this.pollingRequesterMap[did].refs.length > 0);
        });
        dids.forEach(did => {
            this.fetchDid(did);
        });
    }
    fetchDid(did) {
        const { activeInstance } = _stores_UIStore__WEBPACK_IMPORTED_MODULE_1__.UIStore.getRawState();
        if (!activeInstance) {
            return;
        }
        const type = this.pollingRequesterMap[did].type;
        switch (type) {
            case 'file':
                _Actions__WEBPACK_IMPORTED_MODULE_2__.actions
                    .getFileDIDDetails(activeInstance.name, did, true)
                    .then(details => {
                    if (!isBusyStatus(details.status)) {
                        delete this.pollingRequesterMap[did];
                    }
                });
                break;
            case 'collection': {
                // Optimistically set FETCHING status if no data exists
                const existingData = _stores_UIStore__WEBPACK_IMPORTED_MODULE_1__.UIStore.getRawState().collectionDetails[did];
                if (!existingData) {
                    _stores_UIStore__WEBPACK_IMPORTED_MODULE_1__.UIStore.update(s => {
                        s.collectionDetails[did] = [
                            {
                                status: 'FETCHING',
                                did: did,
                                path: undefined,
                                size: 0,
                                message: 'Fetching replica information...'
                            }
                        ];
                    });
                }
                _Actions__WEBPACK_IMPORTED_MODULE_2__.actions
                    .getCollectionDIDDetails(activeInstance.name, did, true)
                    .then(didDetails => {
                    if (!didDetails.find(d => isBusyStatus(d.status))) {
                        delete this.pollingRequesterMap[did];
                    }
                });
                break;
            }
        }
    }
}
const didPollingManager = new DIDPollingManager();
//eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
function withPollingManager(Component) {
    return class WithPollingManager extends (react__WEBPACK_IMPORTED_MODULE_0___default().Component) {
        //eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
        render() {
            const { ...props } = this.props;
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Component, { ...props, didPollingManager: didPollingManager }));
        }
    };
}


/***/ }),

/***/ "./lib/utils/Helpers.js":
/*!******************************!*\
  !*** ./lib/utils/Helpers.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   checkVariableNameValid: () => (/* binding */ checkVariableNameValid),
/* harmony export */   computeCollectionState: () => (/* binding */ computeCollectionState),
/* harmony export */   toHumanReadableSize: () => (/* binding */ toHumanReadableSize)
/* harmony export */ });
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020-2021
 * - Giovanni Guerrieri, <giovanni.guerrieri@cern.ch>, 2025
 */
const computeCollectionState = (files) => {
    if (!files) {
        return false;
    }
    if (files.length === 0) {
        return 'EMPTY';
    }
    const fetching = files.find(file => file.status === 'FETCHING');
    if (fetching) {
        return 'FETCHING';
    }
    const available = files.find(file => file.status === 'OK');
    const notAvailable = files.find(file => file.status === 'NOT_AVAILABLE');
    const replicating = files.find(file => file.status === 'REPLICATING');
    const stuck = files.find(file => file.status === 'STUCK');
    if (replicating) {
        return 'REPLICATING';
    }
    if (stuck) {
        return 'STUCK';
    }
    if (!available) {
        return 'NOT_AVAILABLE';
    }
    if (notAvailable) {
        return 'PARTIALLY_AVAILABLE';
    }
    return 'AVAILABLE';
};
const checkVariableNameValid = (variableName) => {
    // Empty string
    if (!variableName) {
        return false;
    }
    // Includes non-alphanumeric and non-underscore characters
    if (!variableName.match(/^[a-zA-Z0-9_]*$/)) {
        return false;
    }
    // Begins with number
    if (!isNaN(parseInt(variableName.charAt(0)))) {
        return false;
    }
    return true;
};
const toHumanReadableSize = (bytes) => {
    if (bytes / (1024 * 1024 * 1024) >= 1) {
        const sizeInGb = bytes / (1024 * 1024 * 1024);
        return `${Math.round(sizeInGb * 100) / 100}GiB`;
    }
    else if (bytes / (1024 * 1024) >= 1) {
        const sizeInMb = bytes / (1024 * 1024);
        return `${Math.round(sizeInMb * 100) / 100}MiB`;
    }
    else if (bytes / 1024 >= 1) {
        const sizeInKb = bytes / 1024;
        return `${Math.round(sizeInKb * 100) / 100}KiB`;
    }
    else {
        return `${bytes}B`;
    }
};


/***/ }),

/***/ "./lib/utils/NotebookListener.js":
/*!***************************************!*\
  !*** ./lib/utils/NotebookListener.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NotebookListener: () => (/* binding */ NotebookListener),
/* harmony export */   useNotebookResolveStatusStore: () => (/* binding */ useNotebookResolveStatusStore)
/* harmony export */ });
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! pullstate */ "webpack/sharing/consume/default/pullstate/pullstate");
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(pullstate__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _stores_UIStore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../stores/UIStore */ "./lib/stores/UIStore.js");
/* harmony import */ var _const__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../const */ "./lib/const.js");
/* harmony import */ var _utils_Actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utils/Actions */ "./lib/utils/Actions.js");
/* harmony import */ var _widgets_InjectNotebookToolbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../widgets/InjectNotebookToolbar */ "./lib/widgets/InjectNotebookToolbar.js");
/* harmony import */ var _Helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Helpers */ "./lib/utils/Helpers.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 * - Enrique Garcia, (CERN), 2024
 */






const StatusStore = new pullstate__WEBPACK_IMPORTED_MODULE_0__.Store({ status: {} });
function useNotebookResolveStatusStore() {
    const resolveStatus = (0,pullstate__WEBPACK_IMPORTED_MODULE_0__.useStoreState)(StatusStore, s => s.status);
    return resolveStatus;
}
class NotebookListener {
    constructor(options) {
        this.kernelNotebookMapping = {};
        this.options = options;
        this.setup();
    }
    setup() {
        const { notebookTracker } = this.options;
        const instanceConfigurationChange = () => {
            StatusStore.update(s => {
                s.status = {};
            });
            notebookTracker.forEach(p => this.reinject(p));
        };
        _stores_UIStore__WEBPACK_IMPORTED_MODULE_1__.UIStore.subscribe(s => s.activeInstance, activeInstance => {
            if (activeInstance) {
                instanceConfigurationChange();
            }
        });
        notebookTracker.widgetAdded.connect(this.onNotebookOpened, this);
    }
    onNotebookOpened(sender, panel) {
        panel.sessionContext.statusChanged.connect((sender, status) => {
            var _a;
            if (status === 'restarting') {
                const kernel = (_a = sender.session) === null || _a === void 0 ? void 0 : _a.kernel;
                if (kernel) {
                    this.onKernelRestarted(panel, kernel);
                }
                panel.sessionContext.ready.then(() => {
                    if (kernel) {
                        this.onKernelAttached(panel, kernel);
                    }
                });
            }
        });
        panel.sessionContext.kernelChanged.connect((sender, changed) => {
            const oldKernel = changed.oldValue;
            if (oldKernel) {
                this.onKernelDetached(panel, oldKernel);
            }
            const newKernel = changed.newValue;
            if (newKernel) {
                panel.sessionContext.ready.then(() => {
                    this.onKernelAttached(panel, newKernel);
                });
            }
        });
        this.insertInjectButton(panel);
    }
    insertInjectButton(notebookPanel) {
        const onClick = () => {
            var _a, _b;
            if ((_b = (_a = notebookPanel.sessionContext) === null || _a === void 0 ? void 0 : _a.session) === null || _b === void 0 ? void 0 : _b.kernel) {
                this.reinject(notebookPanel);
            }
        };
        const injectNotebookButtonWidget = new _widgets_InjectNotebookToolbar__WEBPACK_IMPORTED_MODULE_2__.InjectNotebookToolbar({
            notebookPanel,
            onClick
        });
        notebookPanel.toolbar.insertAfter('spacer', 'InjectButton', injectNotebookButtonWidget);
    }
    onKernelRestarted(notebook, kernelConnection) {
        this.clearKernelResolverStatus(kernelConnection.id);
    }
    onKernelDetached(notebook, kernelConnection) {
        this.clearKernelResolverStatus(kernelConnection.id);
        this.deleteKernelNotebookMapping(kernelConnection.id);
    }
    onKernelAttached(notebook, kernelConnection) {
        this.setKernelNotebookMapping(kernelConnection.id, notebook.id);
        this.setupKernelReceiverComm(kernelConnection);
        const activeNotebookAttachments = this.getAttachmentsFromMetadata(notebook);
        this.injectAttachments(kernelConnection, activeNotebookAttachments);
    }
    clearKernelResolverStatus(kernelConnectionId) {
        const notebookId = this.getNotebookIdFromKernelConnectionId(kernelConnectionId);
        StatusStore.update(s => {
            s.status[notebookId] = {};
        });
    }
    setupKernelReceiverComm(kernelConnection) {
        kernelConnection.registerCommTarget(_const__WEBPACK_IMPORTED_MODULE_3__.COMM_NAME_FRONTEND, (comm, openMsg) => {
            comm.onMsg = msg => {
                this.processIncomingMessage(kernelConnection, comm, msg);
            };
            this.processIncomingMessage(kernelConnection, comm, openMsg);
        });
    }
    processIncomingMessage(kernelConnection, comm, msg) {
        const data = msg.content.data;
        if (data.action === 'request-inject') {
            const { activeInstance } = _stores_UIStore__WEBPACK_IMPORTED_MODULE_1__.UIStore.getRawState();
            const notebookId = this.getNotebookIdFromKernelConnectionId(kernelConnection.id);
            const { notebookTracker } = this.options;
            const notebook = notebookTracker.find(p => p.id === notebookId);
            if (!notebook || !activeInstance) {
                return;
            }
            const activeNotebookAttachments = this.getAttachmentsFromMetadata(notebook);
            this.resolveAttachments(activeNotebookAttachments, kernelConnection.id).then(injections => {
                return comm
                    .send({ action: 'inject', dids: injections })
                    .done.then(() => {
                    injections.forEach(injection => this.setResolveStatus(kernelConnection.id, injection.did, 'READY'));
                })
                    .catch(e => {
                    console.error(e);
                    injections.forEach(injection => this.setResolveStatus(kernelConnection.id, injection.did, 'FAILED'));
                });
            });
        }
    }
    injectUninjected(notebookPanel) {
        var _a, _b;
        const attachments = this.getAttachmentsFromMetadata(notebookPanel);
        const kernel = (_b = (_a = notebookPanel.sessionContext) === null || _a === void 0 ? void 0 : _a.session) === null || _b === void 0 ? void 0 : _b.kernel;
        if (kernel) {
            this.injectUninjectedAttachments(kernel, attachments);
            this.removeNonExistentInjectedAttachments(kernel === null || kernel === void 0 ? void 0 : kernel.id, attachments);
        }
    }
    reinject(notebookPanel) {
        var _a, _b;
        const attachments = this.getAttachmentsFromMetadata(notebookPanel);
        const kernel = (_b = (_a = notebookPanel.sessionContext) === null || _a === void 0 ? void 0 : _a.session) === null || _b === void 0 ? void 0 : _b.kernel;
        if (kernel) {
            this.injectAttachments(kernel, attachments);
        }
    }
    reinjectSpecificDID(notebookPanel, did) {
        var _a, _b;
        const attachments = this.getAttachmentsFromMetadata(notebookPanel);
        const didAttachment = attachments.find(a => a.did === did);
        const kernel = (_b = (_a = notebookPanel.sessionContext) === null || _a === void 0 ? void 0 : _a.session) === null || _b === void 0 ? void 0 : _b.kernel;
        if (kernel && didAttachment) {
            this.injectAttachments(kernel, [didAttachment]);
        }
    }
    getAttachmentsFromMetadata(notebook) {
        var _a, _b;
        const rucioDidAttachments = (_b = (_a = notebook.model) === null || _a === void 0 ? void 0 : _a.getMetadata(_const__WEBPACK_IMPORTED_MODULE_3__.METADATA_ATTACHMENTS_KEY)) !== null && _b !== void 0 ? _b : [];
        const attachedDIDs = rucioDidAttachments;
        return attachedDIDs;
    }
    injectUninjectedAttachments(kernel, attachments) {
        const kernelConnectionId = kernel === null || kernel === void 0 ? void 0 : kernel.id;
        const notebookId = this.getNotebookIdFromKernelConnectionId(kernelConnectionId);
        const notebookStatus = StatusStore.getRawState().status[notebookId] || {};
        const uninjectedAttachments = attachments.filter(a => !notebookStatus[a.did]);
        this.injectAttachments(kernel, uninjectedAttachments);
    }
    removeNonExistentInjectedAttachments(kernelConnectionId, attachments) {
        const notebookId = this.getNotebookIdFromKernelConnectionId(kernelConnectionId);
        StatusStore.update(s => {
            const notebookStatus = s.status[notebookId];
            if (notebookStatus) {
                const injectedDIDs = Object.keys(notebookStatus);
                const nonExistentDIDs = injectedDIDs.filter(did => !attachments.find(a => a.did === did));
                nonExistentDIDs.forEach(nd => delete s.status[notebookId][nd]);
            }
        });
    }
    injectAttachments(kernel, attachments) {
        if (!this.isExtensionProperlySetup() || !attachments) {
            return;
        }
        this.resolveAttachments(attachments, kernel.id)
            .then(injections => {
            return this.injectVariables(kernel, injections);
        })
            .then(() => {
            attachments.forEach(attachment => this.setResolveStatus(kernel.id, attachment.did, 'READY'));
        })
            .catch(e => {
            console.error(e);
            attachments.forEach(attachment => this.setResolveStatus(kernel.id, attachment.did, 'FAILED'));
        });
    }
    injectVariables(kernel, injections) {
        if (injections.length === 0) {
            return Promise.resolve();
        }
        const comm = kernel.createComm(_const__WEBPACK_IMPORTED_MODULE_3__.COMM_NAME_KERNEL);
        return comm
            .open()
            .done.then(() => comm.send({ action: 'inject', dids: injections }).done)
            .then(() => comm.close().done);
    }
    async resolveAttachments(attachments, kernelConnectionId) {
        const promises = attachments.map(a => this.resolveAttachment(a, kernelConnectionId));
        return Promise.all(promises);
    }
    async resolveAttachment(attachment, kernelConnectionId) {
        const { variableName, type, did } = attachment;
        this.setResolveStatus(kernelConnectionId, did, 'RESOLVING');
        try {
            if (type === 'collection') {
                const didDetails = await this.resolveCollectionDIDDetails(did);
                const files = this.getCollectionFiles(didDetails);
                this.setResolveStatus(kernelConnectionId, did, 'PENDING_INJECTION');
                const collectionStatus = (0,_Helpers__WEBPACK_IMPORTED_MODULE_4__.computeCollectionState)(didDetails);
                const didAvailable = collectionStatus === 'AVAILABLE';
                return { type: 'collection', variableName, files, did, didAvailable };
            }
            else {
                const didDetails = await this.resolveFileDIDDetails(did);
                const file = this.getFile(didDetails);
                this.setResolveStatus(kernelConnectionId, did, 'PENDING_INJECTION');
                const fileStatus = didDetails.status;
                const didAvailable = fileStatus === 'OK';
                return {
                    type: 'file',
                    variableName,
                    files: file ? [file] : null,
                    did,
                    didAvailable
                };
            }
        }
        catch (e) {
            this.setResolveStatus(kernelConnectionId, did, 'FAILED');
            throw e;
        }
    }
    setResolveStatus(kernelConnectionId, did, status) {
        const notebookId = this.getNotebookIdFromKernelConnectionId(kernelConnectionId);
        StatusStore.update(s => {
            if (!s.status[notebookId]) {
                s.status[notebookId] = {};
            }
            s.status[notebookId][did] = status;
        });
    }
    getCollectionFiles(didDetails) {
        return didDetails
            .map(d => this.getFile(d))
            .filter(p => !!p);
    }
    getFile(didDetails) {
        if (!didDetails.path) {
            return null;
        }
        return { path: didDetails.path, pfn: didDetails.pfn };
    }
    async resolveFileDIDDetails(did) {
        const { activeInstance } = _stores_UIStore__WEBPACK_IMPORTED_MODULE_1__.UIStore.getRawState();
        if (!activeInstance) {
            throw new Error('activeInstance cannot be empty');
        }
        return _utils_Actions__WEBPACK_IMPORTED_MODULE_5__.actions.getFileDIDDetails(activeInstance.name, did);
    }
    async resolveCollectionDIDDetails(did) {
        const { activeInstance } = _stores_UIStore__WEBPACK_IMPORTED_MODULE_1__.UIStore.getRawState();
        if (!activeInstance) {
            throw new Error('activeInstance cannot be empty');
        }
        return _utils_Actions__WEBPACK_IMPORTED_MODULE_5__.actions.getCollectionDIDDetails(activeInstance.name, did);
    }
    getNotebookIdFromKernelConnectionId(kernelConnectionId) {
        return this.kernelNotebookMapping[kernelConnectionId];
    }
    setKernelNotebookMapping(kernelConnectionId, notebookId) {
        this.kernelNotebookMapping[kernelConnectionId] = notebookId;
    }
    deleteKernelNotebookMapping(kernelConnectionId) {
        delete this.kernelNotebookMapping[kernelConnectionId];
    }
    isExtensionProperlySetup() {
        const { activeInstance } = _stores_UIStore__WEBPACK_IMPORTED_MODULE_1__.UIStore.getRawState();
        return !!activeInstance;
    }
}


/***/ }),

/***/ "./lib/utils/NotebookPollingListener.js":
/*!**********************************************!*\
  !*** ./lib/utils/NotebookPollingListener.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NotebookPollingListener: () => (/* binding */ NotebookPollingListener)
/* harmony export */ });
/* harmony import */ var _stores_ExtensionStore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../stores/ExtensionStore */ "./lib/stores/ExtensionStore.js");
/* harmony import */ var _stores_UIStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../stores/UIStore */ "./lib/stores/UIStore.js");
/* harmony import */ var _DIDPollingManager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DIDPollingManager */ "./lib/utils/DIDPollingManager.js");
/* harmony import */ var _Actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Actions */ "./lib/utils/Actions.js");
/* harmony import */ var _Helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Helpers */ "./lib/utils/Helpers.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */





const isBusyStatus = (status) => status === 'REPLICATING' || status === 'FETCHING';
const isBusyCollectionState = (state) => state === 'REPLICATING' || state === 'FETCHING';
class NotebookPollingListener {
    constructor(notebookListener) {
        this.activePolling = [];
        this.activeNotebookAttachmentDIDs = [];
        this.notebookListener = notebookListener;
        this.pollingRef = new _DIDPollingManager__WEBPACK_IMPORTED_MODULE_0__.PollingRequesterRef();
        // Listen to change in attachments
        _stores_ExtensionStore__WEBPACK_IMPORTED_MODULE_1__.ExtensionStore.subscribe(s => s.activeNotebookAttachment, attachments => {
            this.removeUnfocusedDIDs(attachments);
            this.processNewAttachments(attachments);
            this.activeNotebookAttachmentDIDs = (attachments === null || attachments === void 0 ? void 0 : attachments.map(a => a.did)) || [];
        });
        // Listen to change in file status
        _stores_UIStore__WEBPACK_IMPORTED_MODULE_2__.UIStore.subscribe(s => s.fileDetails, (fileDetails, state, prevFileDetails) => {
            if (!fileDetails) {
                return;
            }
            const listenedFileDetails = Object.keys(fileDetails)
                .filter(did => this.activeNotebookAttachmentDIDs.includes(did))
                .map(did => ({
                did,
                file: {
                    current: fileDetails[did],
                    prev: prevFileDetails[did]
                }
            }));
            listenedFileDetails.forEach(({ did, file }) => {
                var _a;
                if (isBusyStatus(file.current.status)) {
                    this.enablePolling(did, 'file');
                }
                else {
                    if (this.activePolling.includes(did)) {
                        this.disablePolling(did);
                    }
                    if (file.current.status === 'OK' &&
                        isBusyStatus((_a = file.prev) === null || _a === void 0 ? void 0 : _a.status)) {
                        const { activeNotebookPanel } = _stores_ExtensionStore__WEBPACK_IMPORTED_MODULE_1__.ExtensionStore.getRawState();
                        if (activeNotebookPanel) {
                            this.notebookListener.reinjectSpecificDID(activeNotebookPanel, did);
                        }
                    }
                }
            });
        });
        // Listen to change in collection status
        _stores_UIStore__WEBPACK_IMPORTED_MODULE_2__.UIStore.subscribe(s => s.collectionDetails, (collectionDetails, state, prevCollectionDetails) => {
            if (!collectionDetails) {
                return;
            }
            const listenedCollectionDetails = Object.keys(collectionDetails)
                .filter(did => this.activeNotebookAttachmentDIDs.includes(did))
                .map(did => ({
                did,
                file: {
                    current: collectionDetails[did],
                    prev: prevCollectionDetails[did]
                }
            }));
            listenedCollectionDetails.forEach(({ did, file }) => {
                const currentCollectionState = (0,_Helpers__WEBPACK_IMPORTED_MODULE_3__.computeCollectionState)(file.current);
                if (isBusyCollectionState(currentCollectionState)) {
                    this.enablePolling(did, 'collection');
                }
                else {
                    if (this.activePolling.includes(did)) {
                        this.disablePolling(did);
                    }
                    const prevCollectionState = (0,_Helpers__WEBPACK_IMPORTED_MODULE_3__.computeCollectionState)(file.prev);
                    if (currentCollectionState === 'AVAILABLE' &&
                        isBusyCollectionState(prevCollectionState)) {
                        const { activeNotebookPanel } = _stores_ExtensionStore__WEBPACK_IMPORTED_MODULE_1__.ExtensionStore.getRawState();
                        if (activeNotebookPanel) {
                            this.notebookListener.reinjectSpecificDID(activeNotebookPanel, did);
                        }
                    }
                }
            });
        });
    }
    removeUnfocusedDIDs(attachments = []) {
        const shouldNoLongerPoll = this.activePolling.filter(did => !attachments.find(a => a.did === did));
        shouldNoLongerPoll.forEach(did => this.disablePolling(did));
    }
    processNewAttachments(attachments = []) {
        const newlyAdded = attachments.filter(a => !this.activePolling.find(did => did === a.did));
        newlyAdded.forEach(attachment => {
            this.shouldEnablePolling(attachment).then(shouldEnable => {
                if (shouldEnable) {
                    this.enablePolling(attachment.did, attachment.type);
                }
            });
        });
    }
    async shouldEnablePolling(attachment) {
        const { activeInstance } = _stores_UIStore__WEBPACK_IMPORTED_MODULE_2__.UIStore.getRawState();
        if (!activeInstance) {
            return false;
        }
        if (attachment.type === 'file') {
            const didDetails = await _Actions__WEBPACK_IMPORTED_MODULE_4__.actions.getFileDIDDetails(activeInstance.name, attachment.did, false, true);
            return isBusyStatus(didDetails.status);
        }
        else {
            const didDetails = await _Actions__WEBPACK_IMPORTED_MODULE_4__.actions.getCollectionDIDDetails(activeInstance.name, attachment.did, false, true);
            return didDetails.find(d => isBusyStatus(d.status));
        }
    }
    enablePolling(did, type) {
        _DIDPollingManager__WEBPACK_IMPORTED_MODULE_0__.didPollingManager.requestPolling(did, type, this.pollingRef, false);
        this.activePolling.push(did);
    }
    disablePolling(did) {
        _DIDPollingManager__WEBPACK_IMPORTED_MODULE_0__.didPollingManager.disablePolling(did, this.pollingRef);
        this.activePolling = this.activePolling.filter(d => d !== did);
    }
}


/***/ }),

/***/ "./lib/utils/useInterval.js":
/*!**********************************!*\
  !*** ./lib/utils/useInterval.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ useInterval)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useInterval(callback, delay) {
    const savedCallback = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
    // Remember the latest callback.
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        savedCallback.current = callback;
    }, [callback]);
    // Set up the interval.
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        function tick() {
            const callback = savedCallback.current;
            callback === null || callback === void 0 ? void 0 : callback();
        }
        if (delay !== null) {
            const id = setInterval(tick, delay);
            return () => clearInterval(id);
        }
    }, [delay]);
}


/***/ }),

/***/ "./lib/widgets/InjectNotebookToolbar.js":
/*!**********************************************!*\
  !*** ./lib/widgets/InjectNotebookToolbar.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InjectNotebookToolbar: () => (/* binding */ InjectNotebookToolbar)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_NotebookListener__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/NotebookListener */ "./lib/utils/NotebookListener.js");
/* harmony import */ var _components_Spinning__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Spinning */ "./lib/components/Spinning.js");
/* harmony import */ var _icons_RucioIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../icons/RucioIcon */ "./lib/icons/RucioIcon.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */






const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_2__.createUseStyles)({
    main: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        padding: '0 8px 0 8px',
        borderRadius: '4px',
        cursor: 'pointer',
        '&:hover': {
            background: 'var(--jp-layout-color2)'
        }
    },
    ready: {
        color: 'var(--jp-success-color0)'
    },
    failed: {
        color: 'var(--jp-error-color1)'
    },
    resolving: {
        color: 'var(--jp-rucio-yellow-color)'
    },
    injecting: {
        color: '#c0ca33'
    },
    rucioIcon: {
        marginRight: '4px',
        marginTop: '2px'
    },
    statusIcon: {
        fontSize: '16px',
        marginRight: '4px'
    },
    readyIcon: {
        extend: 'statusIcon',
        color: 'var(--jp-success-color0)'
    },
    failedIcon: {
        extend: 'statusIcon',
        color: 'var(--jp-error-color1)'
    },
    resolvingIcon: {
        extend: 'statusIcon',
        color: 'var(--jp-rucio-yellow-color)'
    },
    pendingInjectionIcon: {
        extend: 'statusIcon',
        color: '#c0ca33'
    }
});
const Panel = ({ notebookPanel, onClick }) => {
    const classes = useStyles();
    const notebookResolveStatusStore = (0,_utils_NotebookListener__WEBPACK_IMPORTED_MODULE_3__.useNotebookResolveStatusStore)();
    const notebookResolveStatus = notebookResolveStatusStore[notebookPanel.id];
    const statuses = notebookResolveStatus
        ? Object.keys(notebookResolveStatus).map(k => notebookResolveStatus[k])
        : null;
    const computeSummarizedStatus = (statuses) => {
        if (!statuses) {
            return null;
        }
        else if (statuses.length === 0) {
            return 'NOT_RESOLVED';
        }
        else if (statuses.includes('FAILED')) {
            return 'FAILED';
        }
        else if (statuses.includes('NOT_RESOLVED')) {
            return 'NOT_RESOLVED';
        }
        else if (statuses.includes('RESOLVING')) {
            return 'RESOLVING';
        }
        else if (statuses.includes('PENDING_INJECTION')) {
            return 'PENDING_INJECTION';
        }
        else {
            return 'READY';
        }
    };
    const summmarizedStatus = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => computeSummarizedStatus(statuses), [notebookResolveStatus]);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, !!summmarizedStatus && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.main, onClick: onClick },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ResolverStatusIcon, { status: summmarizedStatus }),
        summmarizedStatus === 'NOT_RESOLVED' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Attach Variables")),
        summmarizedStatus === 'FAILED' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: classes.failed }, "Failed to Attach")),
        summmarizedStatus === 'RESOLVING' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: classes.resolving }, "Resolving")),
        summmarizedStatus === 'PENDING_INJECTION' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: classes.injecting }, "Attaching")),
        summmarizedStatus === 'READY' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: classes.ready }, "Ready"))))));
};
const ResolverStatusIcon = ({ status }) => {
    const classes = useStyles();
    switch (status) {
        case 'RESOLVING':
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Spinning__WEBPACK_IMPORTED_MODULE_4__.Spinning, { className: `${classes.resolvingIcon} material-icons` }, "hourglass_top"));
        case 'PENDING_INJECTION':
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Spinning__WEBPACK_IMPORTED_MODULE_4__.Spinning, { className: `${classes.pendingInjectionIcon} material-icons` }, "hourglass_top"));
        case 'READY':
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.readyIcon} material-icons` }, "check_circle"));
        case 'FAILED':
            return react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.failedIcon} material-icons` }, "cancel");
        default:
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_icons_RucioIcon__WEBPACK_IMPORTED_MODULE_5__.rucioIcon.react, { tag: "span", className: classes.rucioIcon, width: "16px", height: "16px" }));
    }
};
const PANEL_CLASS = 'jp-RucioExtensionInjectToolbar';
class InjectNotebookToolbar extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.VDomRenderer {
    constructor(options) {
        super();
        super.addClass(PANEL_CLASS);
        this.options = options;
    }
    render() {
        const { notebookPanel, onClick } = this.options;
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Panel, { notebookPanel: notebookPanel, onClick: onClick });
    }
}


/***/ }),

/***/ "./lib/widgets/SidebarPanel.js":
/*!*************************************!*\
  !*** ./lib/widgets/SidebarPanel.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SidebarPanel: () => (/* binding */ SidebarPanel)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-jss */ "webpack/sharing/consume/default/react-jss/react-jss");
/* harmony import */ var react_jss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! pullstate */ "webpack/sharing/consume/default/pullstate/pullstate");
/* harmony import */ var pullstate__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(pullstate__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Header */ "./lib/components/Header.js");
/* harmony import */ var _stores_UIStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../stores/UIStore */ "./lib/stores/UIStore.js");
/* harmony import */ var _icons_RucioIcon__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../icons/RucioIcon */ "./lib/icons/RucioIcon.js");
/* harmony import */ var _components_MenuBar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../components/MenuBar */ "./lib/components/MenuBar.js");
/* harmony import */ var _components_Explore_ExploreTab__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../components/@Explore/ExploreTab */ "./lib/components/@Explore/ExploreTab.js");
/* harmony import */ var _components_Notebook_NotebookTab__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../components/@Notebook/NotebookTab */ "./lib/components/@Notebook/NotebookTab.js");
/* harmony import */ var _components_Settings_SettingsTab__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../components/@Settings/SettingsTab */ "./lib/components/@Settings/SettingsTab.js");
/* harmony import */ var _components_Uploads_UploadsTab__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../components/@Uploads/UploadsTab */ "./lib/components/@Uploads/UploadsTab.js");
/* harmony import */ var _const__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../const */ "./lib/const.js");
/*
 * Copyright European Organization for Nuclear Research (CERN)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Authors:
 * - Muhammad Aditya Hilmy, <mhilmy@hey.com>, 2020
 */













const useStyles = (0,react_jss__WEBPACK_IMPORTED_MODULE_1__.createUseStyles)({
    panel: {
        height: '100%',
        display: 'flex',
        flexDirection: 'column'
    },
    section: {
        flex: 1
    },
    icon: {
        fontSize: '10pt',
        verticalAlign: 'middle'
    },
    iconText: {
        verticalAlign: 'middle',
        paddingLeft: '4px'
    },
    container: {
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        overflow: 'auto'
    },
    menuBar: {
        marginTop: '16px'
    },
    content: {
        flex: 1,
        overflow: 'auto',
        '& > div': {
            height: '100%'
        }
    },
    instanceOption: {
        lineHeight: 0
    },
    infoIcon: {
        fontSize: '15px'
    },
    hidden: {
        display: 'none'
    }
});
const Panel = () => {
    const classes = useStyles();
    const activeInstance = (0,pullstate__WEBPACK_IMPORTED_MODULE_3__.useStoreState)(_stores_UIStore__WEBPACK_IMPORTED_MODULE_4__.UIStore, s => s.activeInstance);
    const [activeMenu, setActiveMenu] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(activeInstance ? 1 : 3);
    const menus = [
        { title: 'Explore', value: 1, right: false, disabled: !activeInstance },
        { title: 'Notebook', value: 2, right: false, disabled: !activeInstance },
        {
            title: (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.instanceOption },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.infoIcon} material-icons` }, "settings"))),
            value: 3,
            right: true
        },
        {
            title: (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.instanceOption },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("i", { className: `${classes.infoIcon} material-icons` }, "upload"))),
            value: 4,
            right: true
        }
    ];
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.panel },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Header__WEBPACK_IMPORTED_MODULE_5__.Header, null),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.container },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.menuBar },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_MenuBar__WEBPACK_IMPORTED_MODULE_6__.MenuBar, { menus: menus, value: activeMenu, onChange: setActiveMenu })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.content },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: activeMenu !== 1 ? classes.hidden : '' }, activeInstance && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Explore_ExploreTab__WEBPACK_IMPORTED_MODULE_7__.ExploreTab, null)),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: activeMenu !== 2 ? classes.hidden : '' }, activeInstance && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Notebook_NotebookTab__WEBPACK_IMPORTED_MODULE_8__.NotebookTab, null)),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: activeMenu !== 3 ? classes.hidden : '' },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Settings_SettingsTab__WEBPACK_IMPORTED_MODULE_9__.SettingsTab, null)),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: activeMenu !== 4 ? classes.hidden : '' },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_Uploads_UploadsTab__WEBPACK_IMPORTED_MODULE_10__.UploadsTab, { visible: activeMenu === 4 }))))));
};
const ErrorPanel = ({ error }) => {
    const classes = useStyles();
    return react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.content }, error);
};
const PANEL_CLASS = 'jp-RucioExtensionPanel';
class SidebarPanel extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__.VDomRenderer {
    constructor(options, error) {
        super();
        super.addClass(PANEL_CLASS);
        super.title.closable = true;
        super.title.icon = _icons_RucioIcon__WEBPACK_IMPORTED_MODULE_11__.rucioIcon;
        const { app, instanceConfig } = options;
        this.app = app;
        if (error) {
            this.error =
                error !== null && error !== void 0 ? error : 'Failed to activate extension. Make sure that the extension is configured and installed properly.';
            return;
        }
        this.instanceConfig = instanceConfig;
        this.populateUIStore(instanceConfig);
    }
    populateUIStore(instanceConfig) {
        const { activeInstance, authType, instances } = instanceConfig;
        const objActiveInstance = instances.find(i => i.name === activeInstance);
        _stores_UIStore__WEBPACK_IMPORTED_MODULE_4__.UIStore.update(s => {
            s.activeInstance = objActiveInstance;
            s.activeAuthType = authType;
            s.instances = instances;
        });
    }
    render() {
        if (this.error) {
            return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ErrorPanel, { error: this.error });
        }
        if (!this.instanceConfig) {
            return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ErrorPanel, { error: "Extension is not configured properly." });
        }
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_const__WEBPACK_IMPORTED_MODULE_12__.JupyterLabAppContext.Provider, { value: this.app },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Panel, null)));
    }
}


/***/ }),

/***/ "./lib/widgets/UploadLogViewerWidget.js":
/*!**********************************************!*\
  !*** ./lib/widgets/UploadLogViewerWidget.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UploadLogViewerWidget: () => (/* binding */ UploadLogViewerWidget)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _stores_UIStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../stores/UIStore */ "./lib/stores/UIStore.js");
/* harmony import */ var _utils_Actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utils/Actions */ "./lib/utils/Actions.js");
/* harmony import */ var _const__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../const */ "./lib/const.js");






var UploadLogViewer;
(function (UploadLogViewer) {
    class Model extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.VDomModel {
        constructor() {
            super(...arguments);
            this._log = '';
        }
        get log() {
            return this._log;
        }
        set log(log) {
            this._log = log;
            this.stateChanged.emit(void 0);
        }
    }
    UploadLogViewer.Model = Model;
    class WidgetBody extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.VDomRenderer {
        constructor(uploadJobId) {
            super(new UploadLogViewer.Model());
            this.uploadJobId = uploadJobId;
            this.title.icon = _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.fileUploadIcon;
            this.id = `${_const__WEBPACK_IMPORTED_MODULE_3__.EXTENSION_ID}:upload-log-viewer-${uploadJobId}`;
            this.title.label = `Upload Job #${uploadJobId}`;
            this.title.closable = true;
        }
        onAfterAttach() {
            const { activeInstance } = _stores_UIStore__WEBPACK_IMPORTED_MODULE_4__.UIStore.getRawState();
            if (activeInstance) {
                _utils_Actions__WEBPACK_IMPORTED_MODULE_5__.actions
                    .fetchUploadJobLog(activeInstance.name, this.uploadJobId)
                    .then(result => {
                    this.model.log = result.text;
                })
                    .catch(e => {
                    console.log(e);
                    this.model.log = 'Error reading upload job log.';
                });
            }
        }
        render() {
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { height: '100%', overflow: 'auto', flex: 1 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { padding: '8px', color: 'var(--jp-ui-font-color0)' } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("code", { style: { whiteSpace: 'pre' } }, this.model.log))));
        }
    }
    UploadLogViewer.WidgetBody = WidgetBody;
})(UploadLogViewer || (UploadLogViewer = {}));
class UploadLogViewerWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.MainAreaWidget {
    constructor(uploadJobId) {
        super({ content: new UploadLogViewer.WidgetBody(uploadJobId) });
    }
}


/***/ })

}]);
//# sourceMappingURL=lib_index_js.24b8c3d35133a22f19e4.js.map